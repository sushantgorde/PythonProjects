__author__ = '308966'
import myfirstpackage.MyModule1 # One way of import
from myfirstpackage import MyModule1 # Second way of import
from myfirstpackage.MyModule1 import add,mul # Third way of import
import myfirstpackage.MyModule1 as pm

print(myfirstpackage.MyModule1.add(10,20))
print(MyModule1.add(10,20))
print(mul(10,20))
print(pm.add(10,20))
