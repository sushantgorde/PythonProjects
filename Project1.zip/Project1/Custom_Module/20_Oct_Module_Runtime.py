__author__ = '308966'
# To load module at runtime we need to -
# import sys module
# Add module path into sys path
# Use the module
# Example follows

import sys

print(sys.path)

sys.path.append("D:\PythonProjects\Project1")

print(sys.path)

