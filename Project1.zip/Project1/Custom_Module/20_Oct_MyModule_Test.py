__author__ = '308966'
from Custom_Module import MyModule
from Custom_Module.MyModule import mul

print(MyModule.add(10,20))
print(mul(10,20))


# Python's way to find out module
# step 1 - Module is internal or not (For example math module)
# Step 2 Current Directory
# Step 3 - In Search Path (As environment variable - PYTHONPATH)
# Step 4 - Installation Library
list1 = list()
list1.append(10)
print(list1)