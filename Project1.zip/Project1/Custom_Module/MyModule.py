__author__ = '308966'
"""
This is sample module to perform simple
arithmetic operations like - add, mul, sub, div
"""

def add(a,b):
    """
    add function accept a and b returns a + b
    both a and b should be integer

    raise ValueError if any of a or b is not an integer
    ex add(10,20) --> 30
    """
    if isinstance(a, int) and isinstance(b, int):
        return a + b
    else:
        raise ValueError("a or b is not an integer value")

def mul(a,b):
    """
    mul function accept a and b returns a * b
    both a and b should be integer

    raise ValueError if any of a or b is not an integer
    ex mul(10,20) --> 200
    """
    if isinstance(a, int) and isinstance(b, int):
        return a * b
    else:
        raise ValueError("a or b is not an integer value")

pi = 3.14
e = 2.77777

# If MyModule is self executable code - then __name__ is __main__
# If it is imported in somefile then __name__ is __module__name

#Mandatory while defining module , it is called standard boiler plate code
# Below piece of code will be executed only when we are running 'MyModule'
if __name__ == '__main__':
    print('This is execution code')
    print(add(10,20))
    print(pi, e)