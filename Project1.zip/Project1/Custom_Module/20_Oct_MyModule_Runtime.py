__author__ = '308966'
from Custom_Module.MyModule import add

# Code in My Module will not be executed as it is secured with __main__ condition -
print(add(10,20))

# Whenever you import user defined module, python creates a folder __pycache__,
# This folder contains a compiled version of module with interpreter version and type.