#!/usr/bin/env python
# coding: utf-8

# In[2]:


# Modules
# OS Module

import os
import shutil

dir_path = input("Enter a path :- ")
file_name = input("Enter a file name :- ")

back_name = file_name + ".bak"
abspath = os.path.join(dir_path,file_name)
parentpath = os.path.abspath(os.path.join(dir_path, os.pardir))
backfile = os.path.join(parentpath, back_name)
shutil.copy(abspath, backfile)


# In[4]:


import os
import shutil
directory_name = input("Please enter a directory name :- ")
zip_directory = os.path.join(directory_name, 'zip')
os.removedirs(zip_directory)
os.mkdir(zip_directory)
for filename in os.listdir(directory_name):
    if filename.endswith(".py") or filename.endswith(".py"):
        back_name = filename + ".bak"
        abspath = os.path.join(directory_name,filename)
        backfile = os.path.join(abspath, back_name)
        shutil.copy(zip_directory, backfile)
    else:
        continue

shutil.make_archive('Zip_Backup_File', 'zip', zip_directory)


# In[ ]:


import os
os.getcwd() # Returns current working directory

#os.chdir('Untitled Folder 1') # Change to directory Untitled Folder 1
#os.chdir("..") # Change to parent directory
#os.getcwd()
#os.chdir('308966')

#os.mkdir('Day 10')# create directory Day 10 in current working directory
#os.chdir('Day 10')

# os.system('dir') # Runs dir command on command prompt
#os.chdir("..")
#os.system('dir')
#os.getcwd()
#os.chdir("D:\PythonProjects")
#os.system('dir')
os.getcwd()

command = os.popen("dir") # Executes dir command and stores output in file handler
print(command.read()) # We can print the contents of command to command prompt


# In[ ]:


# Write a program to except directory name from user and remove all the empty files from that directory
dir1 = input("Please Enter a directory :- ")
os.chdir(dir1)
command = os.popen("dir")
for file in os.listdir(dir1):
    print(file)
    if os.path.isdir(file):
        continue
    else:
        if os.path.getsize(file) > 0:
            continue
        else:
            
            os.remove(file)

