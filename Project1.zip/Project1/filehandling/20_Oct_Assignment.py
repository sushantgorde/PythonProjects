__author__ = '308966'
# Write a program to accept a directory from a user and conver all the files into .zip

import os
import zipfile
import shutil

path = input('Enter a directory name:-')
location_backup = input("Enter a backup folder:-")

zf = zipfile.ZipFile(os.path.join(location_backup,'20th_Oct.zip'),'w')

for dir_path, sub_dir, file in os.walk(path):
    for infile in file:
        if infile.endswith('.py'):
            abspath = os.path.join(dir_path, infile)
            zf.write(abspath)

zf.close()

#Easy way
shutil.make_archive(os.path.join(location_backup,'20thOctober.zip'), 'zip', path)