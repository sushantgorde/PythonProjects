#!/usr/bin/env python
# coding: utf-8

# In[17]:


help(open)
fileN = open('D:\PythonProjects\Test1.txt')
print(fileN.read(5)) # Read first 5 characters
print(fileN.read(10)) # Read Next 10 characters of string
print(fileN.readline()) # Reads next line in string.


# In[3]:





# In[2]:


#Movie Lens 
# WAP to find out top 5 movies which has got highest 5 ratings
# Top 5 movies which has average ratings above 3

movie_rating_dict_2 = dict()
with open('D:\PythonProjects\\ratings.dat') as fileN:
    for line in fileN.readlines():
        line = line.strip()
        ratings_split = line.split("::")
        movieName = ratings_split[1]
        movieRating = int(ratings_split[2])
        if movieRating == 5:
            if movieName in movie_rating_dict :
                movie_rating_dict_2[movieName]+=1
            else :
                movie_rating_dict_2[movieName] = 1
        else :
            continue

for i in movie_rating_dict:  
    print(i,movie_rating_dict[i])
#print(sorted(movie_rating_dict.items(), key = lambda x : x[1], reverse = True)[:5])


# In[ ]:


#Movie Lens 
# WAP to find out top 5 movies which got the highest ratings
movie_rating_dict = dict()
with open('D:\PythonProjects\\ratings.dat') as fileN:
    for line in fileN.readlines():
        line = line.strip()
        ratings_split = line.split("::")
        movieName = ratings_split[1]
        movieRating = int(ratings_split[2])
        if movieName in movie_rating_dict :
            movie_rating_dict[movieName].append(movieRating)
        else :
            movie_rating_dict[movieName] = list()
            movie_rating_dict[movieName].append(movieRating)

new_dict = dict()
for i in movie_rating_dict:
    new_dict[i] =  sum(movie_rating_dict[i]) / len(movie_rating_dict[i])

#print(new_dict.items())
print(sorted(new_dict.items(), key = lambda x : x[1], reverse = True)[:5])


# In[88]:


# Read CSV File which contains following columns - emp_id, emp_name, emp_sal, emp_dept
# Find out averagee salary of an employee from IT Dept
employeeCount, salaryCount = 0, 0 
all_stocks = list()
years_data = dict()
with open('D:\PythonProjects\BSE_Data.csv') as fileN:
    for line in fileN.readlines():
        line = line.strip()
        if(line.startswith('Date')):
            continue
        columns = line.split(',')
        year = columns[0].split('-')
        if year[0].strip() in years_data:
            years_data[year[0].strip()].append(float(columns[4]))
        else :
            myList = [float(columns[4].strip())]
            years_data[year[0].strip()] = myList

for i in years_data:
    print(i, sum(years_data[i]) / len(years_data[i]))
            


# In[62]:


# Find count of each word in file
dict1 = dict()
with open('D:\PythonProjects\Test1.txt') as fileN:
    for line in fileN.readlines():
        for string in line.split():
            if string in dict1 :
                dict1[string]+=1
            else :
                dict1[string] = 1

                
print(dict1)


# In[37]:


# Convert each and every word in upper case
lines = list()
with open('D:\PythonProjects\Test1.txt') as fileN:
    for line in fileN.readlines():
        lines.append(line.strip().upper())
        
print(lines)


# In[53]:


# Convert contents of file in reverse order
lines = list()
with open('D:\PythonProjects\Test1.txt') as fileN:
    for line in reversed(fileN.readlines()):
        lines.append(line.strip())

print(lines)


# In[23]:


lineCount = 0
wordCount = 0
characterCount = 0
# We can iterate over fileN object
with open('D:\PythonProjects\Test1.txt') as fileN:
    for line in fileN:
        characterCount += len(line)
        wordCount+=len(line.split(' '))
        lineCount+=1

str1 = "filename {0} lineCount {1} wordCount {2} characterCount {3} "
print(str1.format('Test1.txt',lineCount,wordCount,characterCount))


# In[22]:


# Context Manager
# If we write python code in context manager then we need not write code to explicitly release resources
lineCount = 0
wordCount = 0
characterCount = 0
with open('D:\PythonProjects\Test1.txt') as fileN:
    for line in fileN.readlines():
        characterCount += len(line)
        wordCount+=len(line.split(' '))
        lineCount+=1

str1 = "filename {0} lineCount {1} wordCount {2} characterCount {3} "
print(str1.format('Test1.txt',lineCount,wordCount,characterCount))


# In[18]:


#To find worcount, line count and character count in string
fileN = open('D:\PythonProjects\Test1.txt')
lineCount = 0
wordCount = 0
characterCount = 0
for line in fileN.readlines():
    characterCount += len(line)
    wordCount+=len(line.split(' '))
    lineCount+=1

str1 = "filename {0} lineCount {1} wordCount {2} characterCount {3} "
print(str1.format('Test1.txt',lineCount,wordCount,characterCount))
fileN.close() # Close the file after open


# In[9]:


help(str.format)


# In[ ]:




