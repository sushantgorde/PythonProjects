#!/usr/bin/env python
# coding: utf-8

# In[2]:


with open('D:\PythonProjects\\ratings2.dat','a') as fileN:
    fileN.write("This is line 1\n")
    fileN.write("This is line 2\n")
    fileN.write("This is line 3\n")
    fileN.writelines(['This is line 4\n','This is line 5\n'])

#fileN.flush() # Write data from buffer to file
#fileN.close() # Write data ffrom buffer to file and release file resources


# In[14]:


movie_rating_dict = dict()
with open('D:\PythonProjects\\ratings.dat','r') as fileN:
    for line in fileN.readlines():
        line = line.strip()
        ratings_split = line.split("::")
        movieName = ratings_split[1]
        movieRating = int(ratings_split[2])
        if movieName in movie_rating_dict :
            movie_rating_dict[movieName].append(movieRating)
        else :
            movie_rating_dict[movieName] = list()
            movie_rating_dict[movieName].append(movieRating)

new_dict = dict()
for i in movie_rating_dict:
    if sum(movie_rating_dict[i]) / len(movie_rating_dict[i]) > 3:
        new_dict[i] =  (sum(movie_rating_dict[i]) / len(movie_rating_dict[i]), len(movie_rating_dict[i]))

print(list(sorted(new_dict.items(), key = lambda x : x[1][1], reverse = True)[:5]))
new_list = list(sorted(new_dict.items(), key = lambda x : x[1][1], reverse = True)[:5])
with open('D:\PythonProjects\\ratings3.dat','w') as fileN:
    for i in new_list:
        fileN.write(new_list[i][0])
        fileN.write("\t")
        fileN.write(str(new_list[i][1][0]))
        fileN.write("\t")
        fileN.write(str(new_list[i][1][1]))
        fileN.write("\n")


# In[18]:


#Write a program to get directory name and file name from user and create a back up of the file in parent directory
dirName = input("Enter directory path :- ")
fileName = input("Enter file name :- ")
print(dirName, fileName)
completeFilePath = dirName + "\\" + fileName
parentDirPath = dirName.split("\\")

data = list()
with open(completeFilePath,'r') as fileN:
    data = fileN.readlines()

with open(dirName + "\\" + "bak"+ fileName,'w') as fileN:
    fileN.writelines(data)



# In[ ]:





# In[ ]:




