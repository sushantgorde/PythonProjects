__author__ = '308966'
import csv
import os
import datetime

path = 'D:\PythonProjects'
file_name = 'BSE_Data.csv'

years_close = dict()

with open(os.path.join(path,file_name)) as csvfile :
    reader = csv.DictReader(csvfile)
    for row in reader:
        print(row)
        year = datetime.datetime.strptime(row['Date'],'%Y-%m-%d').year
        close = float(row['Close'])
        if year in years_close:
            years_close[year].append(close)
        else :
            years_close[year] = list()
            years_close[year].append(close)

for year, close in years_close.items():
    print(year, sum(close) / len(close))

#WAP to upgrade all the packets in any python interpreter within a week