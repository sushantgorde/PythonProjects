from builtins import print
from builtins import int
import sys

__author__ = '308966'
__author__ = '308966'
try:
    number = int(input("Please Enter a number: - "))
    print("100 diveide by number {} is {}".format(number, 100 / number))
except ZeroDivisionError:
    print("Please do not enter 0")
    try:
        number = int(input("Please Enter a number: - "))
        print("100 divide by number {} is {}".format(number, 100 / number))
    except ZeroDivisionError:
        print("Please do not enter 0")
except NameError as N: # N is an object of NameError exception
    print('Error',N)
except Exception as E: # E is a generic exceptions
    print('Error',E)
    print(sys.exc_info()[0])
else: # This block will be executed, Must always be before finally
    print("Inside Else")
finally:
    print('Program Completed')

# 1. try and except are the primary building blocks to handle runtime exceptions in python.
# 2. one try block can have multiple except block to handle different exception class
# 3. try and except block can be nested to handle different exceptions
# 4. try except can have generic except block which can handle any exception thrown by a try block
# 5. try except block can also have finally and else block which will handle a scenario in which the exceptions are not raised.
# 6. with try block except or finally are mandatory
# 7. Exceptions can be user defined which will be created while creating a class derived from the exception class.
# 8. You can also raise an exception using raise function which is builtin in python 3.
