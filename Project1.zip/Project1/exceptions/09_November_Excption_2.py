__author__ = '308966'
from Custom_Module import MyModule

try:
    number1 = int(input("Please enter a number 1:-"))
    number2 = int(input("Please enter a number 2:-"))
    print(MyModule.add(10.1,number2))
except ValueError as E:
    print('Error',E)
finally:
    pass

