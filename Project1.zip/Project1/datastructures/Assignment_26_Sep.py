__author__ = 'Sushant'

print("Hello Python World!!!")
map1 = {1:[1,2,3]}
print(map1)
list1 = ['Sushant','Flexprod']
print(list1)
if 'Sushant' in list1:
    print("If is successful")
else :
    print("Inside Else")

set1 = {1,2,3,4,5,6}
print(set1)