#!/usr/bin/env python
# coding: utf-8

# In[1]:


print([i for i in "Python"])


# In[7]:


names =["Sushant","Trupti","Ram"]
lastnames = ["Gorde","Kale","Joshi"]
for i,j in zip(names, lastnames):
    print(i,j)


# In[2]:


print([i**2 for i in range(1,10)])


# In[3]:


employees = {1:"Sushant", 2:"Trupti", 3:"Spruha"}
print([employees[i] for i in employees])


# In[5]:


n = int(input("Enter The number"))
print([i for i in range(1,n+1)])


# In[6]:


# Print all natural numbers in reverse 
print([i for i in range(1,int(input("Enter The number")))])


# In[8]:


print([i for i in range(int(input("Enter The number")),0,-1)])


# In[9]:


#Print Alphabets from a to z
print([chr(i) for i in range(97,123)])


# In[14]:


#Print all even numbers between 1 to n
n = int(input("Enter the number"))
print([i for i in range(1,n) if i % 2 == 0])


# In[15]:


#Print all odd numbers between 1 to n
n = int(input("Enter the number"))
print([i for i in range(1,n) if i % 2 == 1])


# In[20]:


#Print sum of all natural numbers
n = int(input("Enter the number"))
print(sum(i for i in range(1,n)))


# In[21]:


# Sum of all odd numbers between 1 to n
print(sum(i for i in range(1,100) if i % 2 == 1))


# In[22]:


print(sum(i for i in range(1,5) if i % 2 == 1))


# In[23]:


#Nested loops in comprehension technique
listoflist = [[1,2],[3,4],[5,6]]
print([j for i in listoflist for j in i])


# In[24]:


#Dic of list
dictoflist = {1:[1,2], 2:[3,4], 3:[5,6]}
print([j for i in dictoflist for j in dictoflist[i]])


# In[28]:


#Multiplication table of any number
n = int(input("Enter the number: "))
print([j*n for j in range(1,11) ])


# In[30]:


n = input("Please enter number")
print(len([j for j in n]))


# In[35]:


# Find out prime numbers between 1 to 100

notaprime = {j for i in range(2,10) for j in range(i*2,100,i)}
prime = {i for i in range(2,100) if i not in notaprime}
print(prime)


# In[36]:


#Nested Comprehension
prime = [i for i in range(2,100) if all(i%j for j in range(2,i))]
print(prime)


# In[41]:


#Nested comprehensions
list1 = ["Sushant", "Trupti", "Spruha"]
print({i+1: list1[i] for i in range(0, len(list1))})


# In[42]:


help(enumerate)


# In[43]:


#Enumerate - Function
names = ["Trupti", "Sushant", "Spruha"]
print({i:j for i,j in enumerate(names,start=1)})


# In[47]:


names = ['Sushant', 'Trupti']
lastname = ['Gorde','Kale']

# {Gorde:Sushant, Kale:Trupti}
# {1:(Sushant, Gorde)}
# {1: 'Sushant Gorde'}

print({lastname[j]:names[j] for j in range(0,len(names))})


# In[55]:


names = ['Sushant', 'Trupti']
lastname = ['Gorde','Kale']

print({1: (j for j in enumerate(names))})


# In[56]:


print({i+1: (names[i], lastname[i]) for i in range(len(names))})


# In[57]:


print({i+1: (names[i] + " " + lastname[i]) for i in range(len(names))})


# In[59]:


help(zip)


# In[69]:


names = ["Sushant", "Trupti"]
lastnames = ["Gorde","Kale"]

print({i:j for i,j in zip(lastnames,names)})
print({i+1:j for i,j in enumerate(zip(names,lastnames))})
print({i+1:j[0]+" "+j[1] for i,j in enumerate(zip(names,lastnames))})


# In[70]:


help(enumerate)


# In[75]:


names = ["Sushant","Trupti","Spruha"]
lastnames = ["Gorde","Kale"]
names2=["Test"]
print(list(zip(names,lastnames)))


# In[ ]:


# Functions 

