#!/usr/bin/env python
# coding: utf-8

# In[1]:


dictionary = {1:"Sushant",2:"Trupti",3:"Spruha",4:"Shantanu"}
print(dictionary)


# In[2]:


dir(dict)


# In[2]:


dictionary = {1:"Sushant",2:"Trupti",3:"Spruha",4:"Shantanu"}
#help(dict.values) 
#dictionary.clear() #Removes all elements from dictionary
#dict2 = dictionary.copy() #Creates a shallow copy of dictionary
#dict2[1] = "Ratan" 
#print(dictionary)
#print(dict2)
#print(dictionary.fromkeys((4,3,2,1), "Sushant")) #Create a new dictionary with keys from iterable and values set to value "Sushant".

#print(dictionary.get(2)) #Return value with associated key given, in this case 2

print(dictionary.items()) # Returns list of tuples in dictionary
#print(dictionary.pop(2)) # Removes specified key from dictionary and returns value associated with it
print(dictionary.popitem()) # Returns 2-D tuple and removes it.
#print(dictionary)
#dictionary.setdefault(1,"Default") #Insert key with a default value if key is not present in dictionary
#dictionary.update({5:"TestUpdate1",6:"Testupdate2"})
#dictionary.update((5,6,7))
print(dictionary.values()) #Print values of dictionary


# In[17]:


employees = {1:{'name':'Sushant', 'salary':2000},
            2: {'name':'Trupti', 'salary':3000},
            3: {'name':'Spruha','salary':1500}}

print(list(employees.items()))
sorted(employees.items(),key = lambda x: x[1]['salary'], reverse=True)


# In[ ]:





# In[ ]:




