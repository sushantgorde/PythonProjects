#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import pandas as pd

ratings = pd.read_csv('D:/PythonProjects/ratings.dat',
                     sep='::', engine='python',
                     names=['userId','moviesId', 'rating', 'timestamp'])

#Top 5 movie ids which got highest ratings
print(ratings.groupby('moviesId').size().sort_values(ascending=False).head())

# Top 5 user Ids who likes to provide ratings
print(ratings.groupby('userId').size().sort_values(ascending = False).head())

# Top 5 movies ID which has highest 5 ratings

print(ratings[ratings['rating'] == 5].groupby('moviesId').size().sort_values(ascending = False).head())


# In[2]:


import pandas as pd

movies = pd.read_csv('D:/PythonProjects/movies.dat',
                     sep='::', engine='python',
                     names=['moviesId','Title', 'genre'])

ratings = pd.read_csv('D:/PythonProjects/ratings.dat',
                     sep='::', engine='python',
                     names=['userId','moviesId', 'rating', 'timestamp'])

movies_ratings = pd.merge(movies, ratings, on='moviesId')

print(movies_ratings.groupby(['Title','moviesId']).size().sort_values(ascending = False).head())

# Top 5 movies 


# In[6]:


import pandas as pd

occupation_dict = {
    0:  "other or not specified",
1:  "academic/educator",
2:  "artist",
3:  "clerical/admin",
4:  "college/grad student",
5:  "customer service",
6:  "doctor/health care",
7:  "executive/managerial",
8:  "farmer",
9:  "homemaker",
10:  "K-12 student",
11:  "lawyer",
12:  "programmer",
13:  "retired",
14:  "sales/marketing",
15:  "scientist",
16:  "self-employed",
17:  "technician/engineer",
18:  "tradesman/craftsman",
19:  "unemployed",
20:  "writer"
}

#print(occupation_data)

movies = pd.read_csv('D:/PythonProjects/movies.dat',
                     sep='::', engine='python',
                     names=['moviesId','Title', 'genre'])

ratings = pd.read_csv('D:/PythonProjects/ratings.dat',
                     sep='::', engine='python',
                     names=['userId','moviesId', 'rating', 'timestamp'])

users = pd.read_csv('D:/PythonProjects/users.dat',
                     sep='::', engine='python',
                     names=['userId','gender', 'age', 'occupation','zipcode'])

movies_ratings = pd.merge(movies, ratings, on='moviesId')

ratings_users = pd.merge(users,movies_ratings, on='userId')

# Top 5 user Ids who likes to provide ratings

user_data = ratings_users.groupby(['occupation']).size().sort_values(ascending = False).head()

for key, value in user_data.iteritems():
    print(occupation_dict[key],value)


# In[ ]:





# In[ ]:




