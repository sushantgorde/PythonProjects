#!/usr/bin/env python
# coding: utf-8

# In[3]:


import pandas as pd

#Series
s1 = pd.Series('Python') # Creating series from String
s1 = pd.Series('Python', index=('Course1',)) # Creating series from String

data = {'Course1':'Python', 'Course2':'Java','Course4':'Selenimu'}
s2 = pd.Series(data,index=('Course1','Course2','Course3'))



print(s2)


# In[5]:


s1['Course2'] = 'Java'
s1['Course1'] = 'Go'

del s1['Course1']
print(s1)


# In[12]:


import numpy as np
import pandas as pd

s1 = pd.Series(np.array([1,2,3]))

data = [['Jatin','Rahul'],[35,25],['Pune','Bangalore']]

s2 = pd.Series(data, index=('Name','Age','City'))

print(s2[['Name','Age']])
print(s1)

for key,value in s2.iteritems():
    print(key, value)


# In[9]:


data = {'Pune': 1000, 'Delhi':2000, 'Mumbai':1500,'Chennai':1200,'Chandigarh':None}

cities = pd.Series(data)

#Use Some functions in cities
print(cities[cities.isna()])

#Arithmetic
print(cities*2) # Double the values associated

#Filter , == , > , < , >=, <= , !=
print(cities[cities > 1200])

#functions
print(cities.mean())
print(cities.sum())
print(cities.max())
print(cities.mean())
print(cities.std())
print(cities.var())

print('**' * 20)
print(cities[cities > cities.mean()])
print(cities[cities == cities.max()])
print('**' * 20)

#Selecting multiple keys
print(cities[['Pune','Mumbai']])


# In[13]:


import pandas as pd

data = {'India':['Delhi', 1.3, 1400],
       'China':['Beijing',1.4,1200]}

dfl = pd.DataFrame(data, index =('Capital','Population','PD'))
print(dfl)

dfl['India'] = ['Mumbai', 1.35, 1200] #Modify all values in dataframe

del dfl['China']

dfl['Brazil'] = ['Rio',.8, 1200]

print(dfl)


# In[16]:


import pandas as pd

data = [{'India':'Delhi', 'China':'Beijing'},
       {'India':1.3, 'China':1.4},
       {'India':1400, 'China': 1000}]

dfl = pd.DataFrame(data, index = ('Capital','Population','PD'), columns = ('India', 'China'))

print(dfl)


# In[22]:


df2 = dfl.transpose()
print(df2)

print(df2[df2['Capital'] == 'Delhi']['Population'])


# In[27]:


import pandas as pd

filename = 'D:\PythonProjects\BSE-BOM504067.csv'

zensar = pd.read_csv(filename)
zensar['year'] = pd.to_datetime(zensar['Date']).dt.year
print(zensar[zensar.groupby('year')]['Close'].mean())


# In[46]:


import pandas as pd

filename = 'D:\PythonProjects\BSE-BOM504067.csv'

zensar = pd.read_csv(filename)

#print(zensar)

#print(zensar[['Date']])

zensar['year'] = pd.to_datetime(zensar['Date']).dt.year

#print(zensar[['year', 'Close']].groupby('year').mean())

print(zensar[['year', 'Close']].groupby('year').groups)

#for name, test1 in test:
#    print(name, test['Close'].mean())


# In[2]:


import pandas as pd
import quandl

zensar = quandl.get("BSE/BOM504067", authtoken="aBouPxB6Rozoo728xn5z")
zensar['Date'] = zensar.index


zensar['year'] = pd.to_datetime(zensar['Date']).dt.year
#print(zensar[['year','Close']])


print(zensar[['year','Close']].groupby('year').mean())


# In[56]:


from nsepy import get_history
from datetime import date

data = get_history(symbol="SBIN", start=date(2019,11,21), end=date(2019,11,30))

print(data.head())


# In[ ]:




