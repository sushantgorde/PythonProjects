#!/usr/bin/env python
# coding: utf-8

# # Matplotlib

# In[3]:


import matplotlib.pyplot as plt
import numpy as np

# Fixing random state for reproducibility
np.random.seed(19680801)


plt.rcdefaults()
fig, ax = plt.subplots()

# Example data
people = ('college/grad student', 'other or not specified', 'executive/managerial', 'academic/educator', 'technician/engineer')
y_pos = np.arange(len(people))
performance = [131032, 130499, 105425, 85351, 72816]
error = np.random.rand(len(people))

ax.barh(y_pos, performance, xerr=error, align='center')
ax.set_yticks(y_pos)
ax.set_yticklabels(people)
ax.invert_yaxis()  # labels read top-to-bottom
ax.set_xlabel('Frequency')
ax.set_ylabel('Users')
ax.set_title('Users Graph')

plt.show()


# In[6]:


import pandas as pd
import quandl
import matplotlib.pyplot as plt

import csv
import os
import datetime

path = 'D:\PythonProjects'
file_name = 'BSE_Data.csv'

years_close = dict()

with open(os.path.join(path,file_name)) as csvfile :
    reader = csv.DictReader(csvfile)
    for row in reader:
        year = datetime.datetime.strptime(row['Date'],'%Y-%m-%d').year
        close = float(row['Close'])
        if year in years_close:
            years_close[year].append(close)
        else :
            years_close[year] = list()
            years_close[year].append(close)

years = list()
average_price = list()

for year, close in years_close.items():
    if int(year) % 5 == 0:
        years.append(year)
        average_price.append(sum(close) / len(close))
        
x = years
y = average_price

fig, ax = plt.subplots()
line1, = ax.plot(x,y,'--',linewidth = 2)

ax.legend(loc=' lower right')
plt.show()


# In[ ]:




