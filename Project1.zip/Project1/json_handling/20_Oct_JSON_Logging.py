__author__ = 'Sushant Gorde'
import requests
import json
import datetime
import logging

year_close = dict()

FORMAT = '%(levelname)s: %(asctime)-15s -  %(message)-20s'
logging.basicConfig(format=FORMAT, level=logging.DEBUG, filemode='w',filename='todays.log')

url = 'https://www.quandl.com/api/v3/datasets/BSE/BOM504067.json?api_key=aBouPxB6Rozoo728xn5z'
logging.debug("Hitting URL - {}".format(url))

contents = requests.get(url).text
dataset = json.loads(contents)

count = 0
for row in dataset['dataset']['data']:
    count+=1
    logging.debug("Row {} - data - {}".format(count, row))
    year, close = datetime.datetime.strptime(row[0], '%Y-%m-%d').year, float(row[4])
    if year in year_close:
        year_close[year].append(close)
    else :
        year_close[year] = list()
        year_close[year].append(close)


for year, close in year_close.items():
    print(year, sum(close)/len(close))

logging.debug("Finished execution")
