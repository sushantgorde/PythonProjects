__author__ = 'Sushant Gorde'
import requests
import json
import datetime

year_close = dict()
url = 'https://www.quandl.com/api/v3/datasets/BSE/BOM504067.json?api_key=aBouPxB6Rozoo728xn5z'

contents = requests.get(url).text
dataset = json.loads(contents)

for row in dataset['dataset']['data']:
    year, close = datetime.datetime.strptime(row[0], '%Y-%m-%d').year, float(row[4])
    if year in year_close:
        year_close[year].append(close)
    else :
        year_close[year] = list()
        year_close[year].append(close)

for year, close in year_close.items():
    print(year, sum(close)/len(close))