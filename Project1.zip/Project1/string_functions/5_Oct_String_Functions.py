#!/usr/bin/env python
# coding: utf-8

# In[13]:


#Interview questions - 
#Difference between casefold and lower
#Answer - Both casefold and lower will convert strings to lower case but casefold can work with characters from
# other language as well like German

#Difference between isDigit and isNumeric
#Example of isDigit
#"12345"
#"1233"
#"3"

#Example of isNumeric
#"12345"
#"½¼"
#"½"
#"12345½"

#Find an index


# In[12]:


#startswith, #endswith
string = "This is a string"
print(string.startswith("This"))


# In[11]:


#Join - Join
help(str.join)
print('|'.join("This is a string")) #Concatenate any number of strings.
print('-'.join("Python"))


# In[6]:


#Replace
help(str.replace)
string = "This is simple string"
print(string.replace("is","at"))


# In[8]:


#Split
#help(str.split)
string = "This is a string"
print(string.split(' '))


# In[4]:


dir(str)
#format, replace, strip, stplit, join, startswith, endswith, lower, upper
print("Hello %s, Please pay %d" %('Sushant',10))

#New Style Formatiing
print("Hello {}, Please pay {}".format('Sushant',10))
print("Hello {0}, please pay ${1}".format('Sushant',10))
print("Hello {name}, please pay ${pay}".format(name="Sushant",pay=10))


# In[ ]:




