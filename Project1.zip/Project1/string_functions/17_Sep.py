Python 3.7.3 (v3.7.3:ef4ec6ed12, Mar 25 2019, 22:22:05) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> name = {1: [1,2,3], 2: [456]}
>>> name
{1: [1, 2, 3], 2: [456]}
>>> dir(name)
['__class__', '__contains__', '__delattr__', '__delitem__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__setattr__', '__setitem__', '__sizeof__', '__str__', '__subclasshook__', 'clear', 'copy', 'fromkeys', 'get', 'items', 'keys', 'pop', 'popitem', 'setdefault', 'update', 'values']
>>> setExample = {"Sushant", "Shantanu", "Yogesh"}
>>> setExample
{'Sushant', 'Yogesh', 'Shantanu'}
>>> setExample[0]= "Trupti"
Traceback (most recent call last):
  File "<pyshell#5>", line 1, in <module>
    setExample[0]= "Trupti"
TypeError: 'set' object does not support item assignment
>>> setExample.add(""Trupti)
SyntaxError: invalid syntax
>>> setExample.add("Trupti")
>>> setExample
{'Sushant', 'Yogesh', 'Trupti', 'Shantanu'}
>>> setEample[2]
Traceback (most recent call last):
  File "<pyshell#9>", line 1, in <module>
    setEample[2]
NameError: name 'setEample' is not defined
>>> setExample[2]
Traceback (most recent call last):
  File "<pyshell#10>", line 1, in <module>
    setExample[2]
TypeError: 'set' object is not subscriptable
>>> name[1]
[1, 2, 3]
>>> dir(name)
['__class__', '__contains__', '__delattr__', '__delitem__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__setattr__', '__setitem__', '__sizeof__', '__str__', '__subclasshook__', 'clear', 'copy', 'fromkeys', 'get', 'items', 'keys', 'pop', 'popitem', 'setdefault', 'update', 'values']
>>> len(name)
2
>>> ord('A')
65
>>> chr(74
    )
'J'
>>> name = (1,{4,5,6}, 3)
>>> name
(1, {4, 5, 6}, 3)
>>> name = (1, [2,3,4],5)
>>> name[1][2] = 7
>>> name
(1, [2, 3, 7], 5)
>>> name =[1,[2,3,4],[4,5,[6,7,8]],9]
>>> name[2][2][0]
6
>>> name = (1,{4,5,6}, 3)
>>> name[2] = 4
Traceback (most recent call last):
  File "<pyshell#26>", line 1, in <module>
    name[2] = 4
TypeError: 'tuple' object does not support item assignment
>>> name[1]
{4, 5, 6}
>>> name = {(1,2,3) : "Test"}
>>> name[(1,2,3)]
'Test'
>>> 
