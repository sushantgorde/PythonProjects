Python 3.7.3 (v3.7.3:ef4ec6ed12, Mar 25 2019, 22:22:05) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> name = ""Sushant
SyntaxError: invalid syntax
>>> name = "Sushant"
>>> name[-5:-2:1]
'sha'
>>> input("Please Enter Your name :- ")
Please Enter Your name :- Sushant
'Sushant'
>>> name = input("Please Enter Your name :- ")
Please Enter Your name :- Sushant
>>> age = input("Please Enter Your Age :-")
Please Enter Your Age :-34
>>> print("Hi %s you are %d years old now" %(name,age))
Traceback (most recent call last):
  File "<pyshell#8>", line 1, in <module>
    print("Hi %s you are %d years old now" %(name,age))
TypeError: %d format: a number is required, not str
>>> print("Hi %s you are %s years old now" %(name,age))
Hi Sushant you are 34 years old now
>>> employee = ["Sushant", "34", "20000", "Manager"]
>>> dir(employee)
['__add__', '__class__', '__contains__', '__delattr__', '__delitem__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__gt__', '__hash__', '__iadd__', '__imul__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__reversed__', '__rmul__', '__setattr__', '__setitem__', '__sizeof__', '__str__', '__subclasshook__', 'append', 'clear', 'copy', 'count', 'extend', 'index', 'insert', 'pop', 'remove', 'reverse', 'sort']
>>> len(employee)
4
>>> employee = ["Sushant", 34, 20000, "Manager"]
>>> employee[-5:]
['Sushant', 34, 20000, 'Manager']
>>> employee[:3]
['Sushant', 34, 20000]
>>> 
employee[5] = "Gorde"
Traceback (most recent call last):
  File "<pyshell#16>", line 2, in <module>
    employee[5] = "Gorde"
IndexError: list assignment index out of range
>>> # We cant do direct assignment to out of index
>>> del employee[2]
>>> ## It will shift the elements to the left
>>> print(employee)
['Sushant', 34, 'Manager']
>>> employee
['Sushant', 34, 'Manager']
>>> add(employee)
Traceback (most recent call last):
  File "<pyshell#22>", line 1, in <module>
    add(employee)
NameError: name 'add' is not defined
>>> employee1 = ["Sushant", 34, 20000, "Manager"]
>>> employee + employee1
['Sushant', 34, 'Manager', 'Sushant', 34, 20000, 'Manager']
>>> employee * 2
['Sushant', 34, 'Manager', 'Sushant', 34, 'Manager']
>>> # Only + and * arithmatic operators are overloaded for list

>>> employee == employee1
False
>>> employee > employee1
Traceback (most recent call last):
  File "<pyshell#28>", line 1, in <module>
    employee > employee1
TypeError: '>' not supported between instances of 'str' and 'int'
>>> employee
['Sushant', 34, 'Manager']
>>> employee1
['Sushant', 34, 20000, 'Manager']
>>> employee = employee1
>>> id(employee)
2641788027464
>>> id(employee1)
2641788027464
>>> employee[0] = "Trupti"
>>> employee1
['Trupti', 34, 20000, 'Manager']
>>> # employee and employee1 pointing to same location
>>> employee2 = employee.copy()
>>> employee2
['Trupti', 34, 20000, 'Manager']
>>> # Copy function is a shallow copy
>>> # identity operator is a shallow copy

>>> # identity operator is a deep copy
>>> employee = []
>>> id(employee)
2641788185800
>>> id(employee1)
2641788027464
>>> chr("A")
Traceback (most recent call last):
  File "<pyshell#45>", line 1, in <module>
    chr("A")
TypeError: an integer is required (got type str)
>>> chr(74)
'J'
>>> dir(employee)
['__add__', '__class__', '__contains__', '__delattr__', '__delitem__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__gt__', '__hash__', '__iadd__', '__imul__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__reversed__', '__rmul__', '__setattr__', '__setitem__', '__sizeof__', '__str__', '__subclasshook__', 'append', 'clear', 'copy', 'count', 'extend', 'index', 'insert', 'pop', 'remove', 'reverse', 'sort']
>>> # In case of direct assignment new memory location will be allocated and other list will still point
>>> # Shallow copy = we are copying the elements of one object to another
>>> # Deep Copy = We are pointing to the same memory location. Changes to element will be reflected

>>> "Sushant" in employee
False
>>> "Trupti" not in employee
True
>>> # Membership operators in and not in are also supported in list
>>> employee1 = ["Sushant", 34]
>>> employee2 = ["Trupti", 33]
>>> employees = [employee1, employee2]
>>> print(len(employees))
2
>>> employees[0][0]
'Sushant'
>>> employees[1][1]
33
>>> #2 D List
>>> employees = [1,2,3,[4,5]], [6,7,[8,9,10]]]
SyntaxError: invalid syntax
>>> employees = [1,2,3,[4,5]], [6,7,[8,9,10]]]
SyntaxError: invalid syntax
>>> employees = [1,2,3,[4,5]], [6,7,[8,9,10]]]
SyntaxError: invalid syntax
>>> employees = [[1,2,3,[4,5]], [6,7,[8,9,10]]]
>>> employees[1][2][1]
9
>>> employee = ["Sushant", 34, ["Pune", "Delhi", "Chennai"]]
>>> employee2 = ["Trupti", 33, ["Pune", "Bangalore", "Kolkata", "Delhi"]]
>>> employee3 = ["Shantanu", 35, ["Pune", "Gurgaon"]]
>>> len(emploee[2)]
SyntaxError: invalid syntax
>>> len(employee[2])
3
>>> employees = [employee, employee1, employee2]
>>> len(employees[1][2)]
SyntaxError: invalid syntax
>>> len(employees[2][2])
4
>>> len(employees[0][2])
3
>>> len(employees[0][1])
Traceback (most recent call last):
  File "<pyshell#75>", line 1, in <module>
    len(employees[0][1])
TypeError: object of type 'int' has no len()
>>> len(employees[1][2])
Traceback (most recent call last):
  File "<pyshell#76>", line 1, in <module>
    len(employees[1][2])
IndexError: list index out of range
>>> employees = {"name": "Sushant", "age" : 34, "location": "Pune"}
>>> elpoyees
Traceback (most recent call last):
  File "<pyshell#78>", line 1, in <module>
    elpoyees
NameError: name 'elpoyees' is not defined
>>> employees
{'name': 'Sushant', 'age': 34, 'location': 'Pune'}
>>> employyes["name"] = "Trupti"
Traceback (most recent call last):
  File "<pyshell#80>", line 1, in <module>
    employyes["name"] = "Trupti"
NameError: name 'employyes' is not defined
>>> employees['name'] = "Trupti"
>>> employees
{'name': 'Trupti', 'age': 34, 'location': 'Pune'}
>>> del employees["age"]
>>> employees
{'name': 'Trupti', 'location': 'Pune'}
>>> employees = {"name": "Sushant", "age" : 34, "location": "Pune", "name" : "Trupti"}
>>> employees["name"]
'Trupti'
>>> employees = {"name": "Sushant", "age" : 34, "location": "Pune", "age" : 45}
>>> employees["age"]
45
>>> employees2 = employees
>>> employees2
{'name': 'Sushant', 'age': 45, 'location': 'Pune'}
>>> id(employees2)
2641788267904
>>> id(employees)
2641788267904
>>> "name" in employees2
True
>>> "Pune" in employees2
False
>>> employees3 = employees2.copy()
>>> # This is shallow copy
>>> id(employees3)
2641788267688
>>> employees = {"name" : "Sushant", "age" : 34}
>>> employees2 = {"salary" : 20000, "department" : "IT"}
>>> employees3 = {employees, employees2}
Traceback (most recent call last):
  File "<pyshell#100>", line 1, in <module>
    employees3 = {employees, employees2}
TypeError: unhashable type: 'dict'
>>> employees3 = {{"name" : "Sushant", "age" : 34},{"salary": 20000, "departement" : "IT"}}
Traceback (most recent call last):
  File "<pyshell#101>", line 1, in <module>
    employees3 = {{"name" : "Sushant", "age" : 34},{"salary": 20000, "departement" : "IT"}}
TypeError: unhashable type: 'dict'
>>> employees3 = {1:{"name" : "Sushant", "age" : 34},2:{"salary": 20000, "departement" : "IT"}}
>>> employees4 = {1:{"name" : "Sushant", "age" : 34},2:{"salary": 20000, "departement" : "IT", "Locations" : ["Pune", "Chennai", "Kolkata"]}}
>>> employees4[1]["name"]
'Sushant'
>>> employees4[2]["Locations"]
['Pune', 'Chennai', 'Kolkata']
>>> # This is dictionary of disctionary
>>> employees5 = {1: employees, 2: employees2}
>>> employees6 = {1:["Sushant", 34, "Pune"], 2: ["Trupti", 33, "Chennai"]}
>>> employees6[1][0]
'Sushant'
>>> nem = 'Ethans Technologies'
>>> nem[-1:0]
''
>>> #Tuples
>>> name = ("Sushant", "Shantanu", "Yogesh", "Ratnaveer")
>>> del name[0]
Traceback (most recent call last):
  File "<pyshell#114>", line 1, in <module>
    del name[0]
TypeError: 'tuple' object doesn't support item deletion
>>> name[0]
'Sushant'
>>> name[0] = "Trupti"
Traceback (most recent call last):
  File "<pyshell#116>", line 1, in <module>
    name[0] = "Trupti"
TypeError: 'tuple' object does not support item assignment
>>> len(name)
4
>>> name + name
('Sushant', 'Shantanu', 'Yogesh', 'Ratnaveer', 'Sushant', 'Shantanu', 'Yogesh', 'Ratnaveer')
>>> name * 2
('Sushant', 'Shantanu', 'Yogesh', 'Ratnaveer', 'Sushant', 'Shantanu', 'Yogesh', 'Ratnaveer')
>>> name
('Sushant', 'Shantanu', 'Yogesh', 'Ratnaveer')
>>> name == name
True
>>> name is name
True
>>> "Sushant" in name
True
>>> # If we have to create tuple having one element then you have to provide , at the end otherwise it will take object of that element object
>>> name = ("Sushant")
>>> type(name)
<class 'str'>
>>> name = ("Sushant",)
>>> type(name)
<class 'tuple'>
>>> #Tuple can be used as a key in dictionary
>>> employees = ((), ()) # Tples of Tuples
>>> employees = [(), ()] # List of Tuples
>>> employees = {(), ()} # Set of Tuples
>>> 
>>> #SET
>>> employees = {"Sushant", "Yogesh", "Shantanu", "Ratnaveer"}
>>> employees
{'Ratnaveer', 'Yogesh', 'Shantanu', 'Sushant'}
>>> # Set are unordered
>>> employees[0] # Set doesnt support indexing
Traceback (most recent call last):
  File "<pyshell#138>", line 1, in <module>
    employees[0] # Set doesnt support indexing
TypeError: 'set' object is not subscriptable
>>> manager = {"Sushant", "Swapnil", "Sachin", "Sayan" }
>>> employees - manager # Employees who are not managers
{'Ratnaveer', 'Shantanu', 'Yogesh'}
>>> manager - employees # Managers who are not employees
{'Sayan', 'Sachin', 'Swapnil'}
>>> employees & managers # & - Union of employees and managers with unique values
Traceback (most recent call last):
  File "<pyshell#142>", line 1, in <module>
    employees & managers # & - Union of employees and managers with unique values
NameError: name 'managers' is not defined
>>> employees & manager # & - Union of employees and managers with unique values
{'Sushant'}
>>> employees & manager # & - Intersection of employees and managers with unique values
{'Sushant'}
>>> employees | manager # Union of Employees and Managers
{'Shantanu', 'Ratnaveer', 'Sachin', 'Swapnil', 'Yogesh', 'Sayan', 'Sushant'}
>>> employees ^ manager # Employees and Managers but not both so in this case Sushant will be excluded
{'Shantanu', 'Ratnaveer', 'Sachin', 'Yogesh', 'Sayan', 'Swapnil'}
>>> 
