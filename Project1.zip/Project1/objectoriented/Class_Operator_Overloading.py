__author__ = '308966'
class Team(object):

    def __init__(self, name, *players):
        self.team_name = name
        self.players = players

    def __add__(self, other):
        allplayers = str()
        for player in self.players:
            allplayers+=player + ' '
        for player in other.players:
            allplayers += player + ' '
        return allplayers

    def __str__(self):
        return self.team_name

    def __len__(self):
        count = 0
        for player in self.players:
            count+=1
        return count

    def __gt__(self, other):
        if len(self.players) > len(other.players):
            return True
        else:
            return False

india = Team('India', 'Rohit','Dhawan','Kohli','Rahane','Jadhav')
aus = Team('Australia', 'Warner','Smith','Lee','Starc')

print(india + aus)
print(india > aus)
print(len(india))
print(india)

