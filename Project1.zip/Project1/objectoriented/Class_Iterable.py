__author__ = '308966'
# In order to make iterable class there are 3 rules
# Create class
# Implement __iter__ method
# Implement __next__ method

class Prime(object):

    def __init__(self, start, end):
        self.start = start
        self.end = end

    def __iter__(self):
        return self

    def __next__(self):
        while self.start < self.end:
            for i in range(2,self.start):
                if self.start % i == 0:
                    self.start += 1
                    break
                else:
                    self.start += 1
                    return self.start -1
                continue
        else :
            raise StopIteration('Start exceeding end')

myrange = Prime(2,100)
for i in myrange:
    print(i)


