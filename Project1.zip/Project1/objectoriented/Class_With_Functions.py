__author__ = '308966'
class Car(object):
    no_of_tyres = 5
    steering_type = 'Manual'

    def set_gear_type(self, type):
        # self = audi
        self.type = type #audi.type = 'Automatic'

    def get_gear_type(self):
        return self.type


audi = Car()
merc = Car()

audi.set_gear_type('Automatic')
print(audi.type)

merc.set_gear_type('Automatic')
print(merc.get_gear_type())

print(audi + car) # Will raise an exception



