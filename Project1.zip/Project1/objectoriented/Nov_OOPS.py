__author__ = '308966'
#Object is top / universal class in python - Every class id inherting Object class

class Car(object): // An 'object'
    no_of_tyres = 5
    steering_typ = 'Manual'

audi = Car()
merc = Car()

print(audi.no_of_tyres)
print(audi.steering_typ)

print(merc.no_of_tyres)
print(merc.steering_typ)

print(merc.no_of_tyres)
print(merc.steering_typ)

print(Car.no_of_tyres)
print(Car.steering_typ)


print(Car().no_of_tyres)
print(Car().steering_typ)

