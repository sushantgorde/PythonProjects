__author__ = '308966'

def myPrimeGernarator(start, end):
    while start < end:
        for i in range(2,start):
            if start % i == 0:
                break;
            else:
                yield start
            start+=1


def myGenerator(start , end):
    while start < end:
        yield start
        start += 1


myrange = myGenerator(2,100)
for i in myrange:
    print(i, end=',')


myPrimeRane = myPrimeGernarator(2,100)
for i in myPrimeRane:
    print(i, end=',')