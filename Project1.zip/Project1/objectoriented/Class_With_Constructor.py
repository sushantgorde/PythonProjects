__author__ = '308966'
class Car(object):

    def __init__(self, no_of_tyres, steering_type): #Constructor
        self.no_of_tyres = no_of_tyres
        self.steering_type = steering_type


    def __del__(self):
        print('Removed an instance of Car')

audi = Car(5,'Manual')
merc = Car(no_of_tyres=6,steering_type='Automatic')

print(audi.no_of_tyres)
print(audi.steering_type)

