__author__ = '308966'

class Car(object):

    def __init__(self, steeringType, gearType):
        self.steeringType = steeringType
        self.gearType = gearType

    def gear(self):
        print('Gear Type of Car class is {}'.format(self.gearType))
