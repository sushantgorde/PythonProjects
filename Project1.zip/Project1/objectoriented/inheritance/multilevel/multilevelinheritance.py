__author__ = '308966'

__author__ = '308966'

import objectoriented.inheritance.myownclasses
class Car(object):

    def __init__(self, steeringType, gearType):
        self.steeringType = steeringType
        self.gearType = gearType

    def gear(self):
        print('Gear Type of AmericanCar class is {}'.format(self.gearType))


class EuroCar(Car):

    def gear(self):
        print('Gear Type of EuroCar class is {}'.format(self.gearType))
        super(EuroCar, self).gear() # This will call complete class hierarchy


class AmericanCar(Car):

    def gear(self):
        print('Gear Type of AmericanCar class is {}'.format(self.gearType))
        super(AmericanCar, self).gear() # This will call complete class hierarchy


class IndianCar(EuroCar, AmericanCar):

    def gear(self):
        print('Gear Type of IndianCar class is {}'.format(self.gearType))
        super(IndianCar, self).gear() # This will call complete class hierarchy

audi = IndianCar('Manual', 'Manual')
audi.gear();
# First it will print Indian Car
# Second it will print Euro Car
# Third it will print American Class
# Fourth it will print Car class
# Order is defined horizontally and as we are calling function based on derived class object
# it will consider its hierarchy
# super(IndianCar, self).gear() - Means call super class of IndianCar with audi object
# super(EuroCar, self).gear() # Means call super class of audi object of IndianCar class after EuroCar i.e.
# AmericanCar in this case



