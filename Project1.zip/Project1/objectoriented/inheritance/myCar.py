__author__ = '308966'

import objectoriented.inheritance.myownclasses
class Car(object):

    def __init__(self, steeringType, gearType):
        self.steeringType = steeringType
        self.gearType = gearType

    def gear(self):
        print('Lets assume this is a speed functionality')


class EuroCar(Car):

    def gear(self):
        print('Gear Type of Car class is {}'.format(self.gearType))
        print('Gear Type of Car class is {}'.format(self.gearType))
        super(EuroCar, self).gear() # This will call complete class hierarchy

audi = EuroCar('Manual','Manual')
audi.gear()
# Method overloading is not supported in Python
# In case of Multiple inheritance, it will go from left to right horizontally

