Python 3.7.3 (v3.7.3:ef4ec6ed12, Mar 25 2019, 22:22:05) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> number = int(inpur("Enter number to create table for:"))
Traceback (most recent call last):
  File "<pyshell#0>", line 1, in <module>
    number = int(inpur("Enter number to create table for:"))
NameError: name 'inpur' is not defined
>>> number = int(input("Enter number to create table for:"))
Enter number to create table for:17
>>> counter = 0
>>> while counter <= 10:
	print(number)
	counter+=1;
	number = number * counter

	
17
17
34
102
408
2040
12240
85680
685440
6168960
61689600
>>> counter = 1
>>> number2 = 0
>>> number2 = number
>>> while counter <= 10:
	print(number2)
	counter+=1;
	number2 = number * counter

	
678585600
1357171200
2035756800
2714342400
3392928000
4071513600
4750099200
5428684800
6107270400
6785856000
>>> number = int(input("Enter number to create table for:"))
Enter number to create table for:19
>>> while counter <= 10:
	print(number2)
	counter+=1;
	number2 = number * counter

	
>>> counter = 1
>>> number2 = number
>>> while counter <= 10:
	print(number2)
	counter+=1;
	number2 = number * counter

	
19
38
57
76
95
114
133
152
171
190
>>> name = "Sushant"
>>> name[2]
's'
>>> number = int(input("Please Enter a number:- "))
Please Enter a number:- 4567
>>> numberString = str(number)
>>> counter = 0
>>> while counter <= len(numberString):
	print(numberString[counter])
else :
	print("Done")

	
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4
4Traceback (most recent call last):
  File "<pyshell#29>", line 2, in <module>
    print(numberString[counter])
KeyboardInterrupt
>>> counter = 0
>>> while counter <= len(numberString):
	counter+=1
	print(numberString[counter])
else :
	print("Done")

	
5
6
7
Traceback (most recent call last):
  File "<pyshell#32>", line 3, in <module>
    print(numberString[counter])
IndexError: string index out of range
>>> while counter <= len(numberString):
	counter+=1
else :
	print("number of length of a number is %d" %(counter))

	
number of length of a number is 5
>>> # For Loop
>>> number = int(input("Enter a number: "))
Enter a number: 15
>>> for i in range(1,number):
	print(i)
	i+=1

	
1
2
3
4
5
6
7
8
9
10
11
12
13
14
>>> 
>>> 
>>> # Print natural number in reverse order
>>> number = int(input("Enter a number: "))
Enter a number: 9
>>> for i in range(number,1,-1):
	print(i)

	
9
8
7
6
5
4
3
2
>>> # Print all alphabets from a to z
>>> for i in range(97, 123, 1) :
	print(chr(i))

	
a
b
c
d
e
f
g
h
i
j
k
l
m
n
o
p
q
r
s
t
u
v
w
x
y
z
>>> # Print even numbers between 1 to 100
>>> for i in range(0,100,2):
	print(i)

	
0
2
4
6
8
10
12
14
16
18
20
22
24
26
28
30
32
34
36
38
40
42
44
46
48
50
52
54
56
58
60
62
64
66
68
70
72
74
76
78
80
82
84
86
88
90
92
94
96
98
>>> # Print all odd numbers between 1 to 100
>>> for i in range(1,100,2):
	print(i)

	
1
3
5
7
9
11
13
15
17
19
21
23
25
27
29
31
33
35
37
39
41
43
45
47
49
51
53
55
57
59
61
63
65
67
69
71
73
75
77
79
81
83
85
87
89
91
93
95
97
99
>>> num = int(input("Enter a number :"))
Enter a number :10
>>> sum = 0
>>> for i in range(1,num):
	sum+=i
else :
	print("Sum of first %d numbers is %d" %(num,sum))

	
Sum of first 10 numbers is 45
>>> #Sum of even numbers between 1 to n
>>> sum = 0
>>> num = int(input("Please Enter a number:"))
Please Enter a number:15
>>> for i in range(0,num,2):
	sum+=i
else :
	print("Sum of first %d even numbers is %d" %(num,sum))

	
Sum of first 15 even numbers is 56
>>> sum = 0
>>> num = 15
>>> counter = 0
>>> for i in range(1,num):
	counter+=2
	sum+=counter
else:
	print("Sum of first %d even numbers is %d" %(num,sum))

	
Sum of first 15 even numbers is 210
>>> #Sum of first n even numbers from 1 to n
>>> sum =0
>>> counter = 1
>>> for i in range(1,num):
	counter+=2
	sum+=counter
else:
	print("Sum of first %d even numbers is %d" %(num,sum))

	
Sum of first 15 even numbers is 224
>>> number = int(input("Enter a number: -"))
Enter a number: -17
>>> for i in range(1,10):
	print(number)
	number *=i
else:
	print("Sum of first %d even numbers is %d" %(num,sum))

	
17
17
34
102
408
2040
12240
85680
685440
Sum of first 15 even numbers is 224
>>> number = int(input("Enter a number :"))
Enter a number :18
>>> number2 = number
>>> for i in range(1,10):
	print(number2)
	number2 = number *i

	
18
18
36
54
72
90
108
126
144
>>> number = int(input("Enter a number :"))
Enter a number :17
>>> number2 = 0
>>> for i in range(1,10):
	number2 = number *i
	print(number2)

	
17
34
51
68
85
102
119
136
153
>>> number = int(input("Enter a number"))
Enter a number12345
>>> counter = 0
>>> for i in str(number):
	counter+=1
else:
	print("Number of characters in string is %d" %(counter))

	
Number of characters in string is 5
>>> number = int(input("Please enter a number to check if it is a prime or not:"))
Please enter a number to check if it is a prime or not:17
>>> for i in range(2,number):
	if number%i == 0
	
SyntaxError: invalid syntax
>>> for i in range(2,number):
	if number%i == 0:
		break
else :
	print("Number %d is prime" %(number))

	
Number 17 is prime
>>> # Print prime numbers between 2 to 100
>>> for number in range(2,100):
	for i in range(2,number):
		if number%i == 0:
			break
	else:
		print("%d is a prime number")

%d is a prime number
%d is a prime number
%d is a prime number
%d is a prime number
%d is a prime number
%d is a prime number
%d is a prime number
%d is a prime number
%d is a prime number
%d is a prime number
%d is a prime number
%d is a prime number
%d is a prime number
%d is a prime number
%d is a prime number
%d is a prime number
%d is a prime number
%d is a prime number
%d is a prime number
%d is a prime number
%d is a prime number
%d is a prime number
%d is a prime number
%d is a prime number
%d is a prime number
>>> for number in range(2,100):
	for i in range(2,number):
		if number%i == 0:
			break
	else:
		print("%d is a prime number" %(number))

		
2 is a prime number
3 is a prime number
5 is a prime number
7 is a prime number
11 is a prime number
13 is a prime number
17 is a prime number
19 is a prime number
23 is a prime number
29 is a prime number
31 is a prime number
37 is a prime number
41 is a prime number
43 is a prime number
47 is a prime number
53 is a prime number
59 is a prime number
61 is a prime number
67 is a prime number
71 is a prime number
73 is a prime number
79 is a prime number
83 is a prime number
89 is a prime number
97 is a prime number
>>> for number in range(2,100):
	for i in range(2,number):
		if number%i == 0 or number == 2:
			break
	else:
		print("%d is a prime number" %(number))

		
2 is a prime number
3 is a prime number
5 is a prime number
7 is a prime number
11 is a prime number
13 is a prime number
17 is a prime number
19 is a prime number
23 is a prime number
29 is a prime number
31 is a prime number
37 is a prime number
41 is a prime number
43 is a prime number
47 is a prime number
53 is a prime number
59 is a prime number
61 is a prime number
67 is a prime number
71 is a prime number
73 is a prime number
79 is a prime number
83 is a prime number
89 is a prime number
97 is a prime number
>>> for number in range(2,100):
	for i in range(2,number):
		if number == 2:
			break
		if number%i == 0 or number == 2:
			break
	else:
		print("%d is a prime number" %(number))

		
2 is a prime number
3 is a prime number
5 is a prime number
7 is a prime number
11 is a prime number
13 is a prime number
17 is a prime number
19 is a prime number
23 is a prime number
29 is a prime number
31 is a prime number
37 is a prime number
41 is a prime number
43 is a prime number
47 is a prime number
53 is a prime number
59 is a prime number
61 is a prime number
67 is a prime number
71 is a prime number
73 is a prime number
79 is a prime number
83 is a prime number
89 is a prime number
97 is a prime number
>>> for number in range(2,100):
	for i in range(2,number):
		if number%i == 0 or number == 2:
			break
	else:
		print("%d is a prime number" %(number))

		
2 is a prime number
3 is a prime number
5 is a prime number
7 is a prime number
11 is a prime number
13 is a prime number
17 is a prime number
19 is a prime number
23 is a prime number
29 is a prime number
31 is a prime number
37 is a prime number
41 is a prime number
43 is a prime number
47 is a prime number
53 is a prime number
59 is a prime number
61 is a prime number
67 is a prime number
71 is a prime number
73 is a prime number
79 is a prime number
83 is a prime number
89 is a prime number
97 is a prime number
>>> for number in range(3,100):
	for i in range(2,number):
		if number%i == 0 or number == 2:
			break
	else:
		print("%d is a prime number" %(number))

		
3 is a prime number
5 is a prime number
7 is a prime number
11 is a prime number
13 is a prime number
17 is a prime number
19 is a prime number
23 is a prime number
29 is a prime number
31 is a prime number
37 is a prime number
41 is a prime number
43 is a prime number
47 is a prime number
53 is a prime number
59 is a prime number
61 is a prime number
67 is a prime number
71 is a prime number
73 is a prime number
79 is a prime number
83 is a prime number
89 is a prime number
97 is a prime number
>>> # Program to accept a number from a user and check whether it is an armstrong number
>>> number = int(input("Please Enter to check if it is an armstrong number"))
Please Enter to check if it is an armstrong number560
>>> sum = 0
>>> for i in str(number)
SyntaxError: invalid syntax
>>> for i in str(number):
	sum+= int(i)^len(str(number)
else:
			 
SyntaxError: invalid syntax
>>> sum = 0
>>> for i in str(number):
	sum = sum + int(i)^len(str)
else:
	if sum == number
	
SyntaxError: invalid syntax
>>> for i in str(number):
	sum = sum + int(i)^len(str)
else:
	if sum == number:
		print("%d number is armstrong" %number)

		
Traceback (most recent call last):
  File "<pyshell#156>", line 2, in <module>
    sum = sum + int(i)^len(str)
TypeError: object of type 'type' has no len()
>>> for i in str(number):
	sum = sum + (int(i)^len(str(number)))
else:
	if sum == number:
		print("%d number is armstrong" %number)

		
>>> number = 370
>>> for i in str(number):
	sum = sum + (int(i)^len(str(number)))
else:
	if sum == number:
		print("%d number is armstrong" %number)

		
>>> for i in str(number):
	sum = sum + (int(i)^len(str(number)))
	print("Sum is -",sum)
else:
	if sum == number:
		print("%d number is armstrong" %number)

		
Sum is - 21
Sum is - 25
Sum is - 28
>>> sum = 3 ^ 3
>>> sum
0
>>> for i in str(number):
	sum = sum + (int(i)**len(str(number)))
else:
	if sum == number:
		print("%d number is armstrong" %number)

		
370 number is armstrong
>>> number = 450
>>> for i in str(number):
	sum = sum + (int(i)**len(str(number)))
else:
	if sum == number:
		print("%d number is armstrong" %number)

		
>>> for i in str(number):
	sum = sum + (int(i)**len(str(number)))
else:
	if sum == number:
		print("%d number is armstrong" %number)
	else :
		print("%d is not an armstrong number" %(number))

		
450 is not an armstrong number
>>> for j in range(1,100):
	for i in str(j):
		sum = sum + (int(i)**len(str(j)))
	else:
		if sum == j:
			print("%d number is armstrong" %j)
		else :
			print("%d is not an armstrong number" %(j))

			
1 is not an armstrong number
2 is not an armstrong number
3 is not an armstrong number
4 is not an armstrong number
5 is not an armstrong number
6 is not an armstrong number
7 is not an armstrong number
8 is not an armstrong number
9 is not an armstrong number
10 is not an armstrong number
11 is not an armstrong number
12 is not an armstrong number
13 is not an armstrong number
14 is not an armstrong number
15 is not an armstrong number
16 is not an armstrong number
17 is not an armstrong number
18 is not an armstrong number
19 is not an armstrong number
20 is not an armstrong number
21 is not an armstrong number
22 is not an armstrong number
23 is not an armstrong number
24 is not an armstrong number
25 is not an armstrong number
26 is not an armstrong number
27 is not an armstrong number
28 is not an armstrong number
29 is not an armstrong number
30 is not an armstrong number
31 is not an armstrong number
32 is not an armstrong number
33 is not an armstrong number
34 is not an armstrong number
35 is not an armstrong number
36 is not an armstrong number
37 is not an armstrong number
38 is not an armstrong number
39 is not an armstrong number
40 is not an armstrong number
41 is not an armstrong number
42 is not an armstrong number
43 is not an armstrong number
44 is not an armstrong number
45 is not an armstrong number
46 is not an armstrong number
47 is not an armstrong number
48 is not an armstrong number
49 is not an armstrong number
50 is not an armstrong number
51 is not an armstrong number
52 is not an armstrong number
53 is not an armstrong number
54 is not an armstrong number
55 is not an armstrong number
56 is not an armstrong number
57 is not an armstrong number
58 is not an armstrong number
59 is not an armstrong number
60 is not an armstrong number
61 is not an armstrong number
62 is not an armstrong number
63 is not an armstrong number
64 is not an armstrong number
65 is not an armstrong number
66 is not an armstrong number
67 is not an armstrong number
68 is not an armstrong number
69 is not an armstrong number
70 is not an armstrong number
71 is not an armstrong number
72 is not an armstrong number
73 is not an armstrong number
74 is not an armstrong number
75 is not an armstrong number
76 is not an armstrong number
77 is not an armstrong number
78 is not an armstrong number
79 is not an armstrong number
80 is not an armstrong number
81 is not an armstrong number
82 is not an armstrong number
83 is not an armstrong number
84 is not an armstrong number
85 is not an armstrong number
86 is not an armstrong number
87 is not an armstrong number
88 is not an armstrong number
89 is not an armstrong number
90 is not an armstrong number
91 is not an armstrong number
92 is not an armstrong number
93 is not an armstrong number
94 is not an armstrong number
95 is not an armstrong number
96 is not an armstrong number
97 is not an armstrong number
98 is not an armstrong number
99 is not an armstrong number
>>> for j in range(1,100):
	for i in str(j):
		sum = sum + (int(i)**len(str(j)))
	else:
		if sum == j:
			print("%d number is armstrong" %j)

			
>>> for j in range(1,1000):
	for i in str(j):
		sum = sum + (int(i)**len(str(j)))
	else:
		if sum == j:
			print("%d number is armstrong" %j)

			
>>> sum = 0
>>> for j in range(1,1000):
	for i in str(j):
		sum = sum + (int(i)**len(str(j)))
	else:
		if sum == j:
			print("%d number is armstrong" %j)

			
1 number is armstrong
>>> 
KeyboardInterrupt
>>> 
KeyboardInterrupt
>>> for j in range(1,100):
	sum = 0
	for i in str(j):
		sum = sum + (int(i)**len(str(j)))
	else:
		if sum == j:
			print("%d number is armstrong" %j)

			
1 number is armstrong
2 number is armstrong
3 number is armstrong
4 number is armstrong
5 number is armstrong
6 number is armstrong
7 number is armstrong
8 number is armstrong
9 number is armstrong
>>> #Find frequency of digits in a number
>>> number = input("Please enter a number")
Please enter a number121314345
>>> sampleDict = {:}
SyntaxError: invalid syntax
>>> item = dict()
>>> item = {}
>>> for i in numbers:
	item.add(i)

	
Traceback (most recent call last):
  File "<pyshell#200>", line 1, in <module>
    for i in numbers:
NameError: name 'numbers' is not defined
>>> for i in numbers:
	item.add(i)

	
Traceback (most recent call last):
  File "<pyshell#202>", line 1, in <module>
    for i in numbers:
NameError: name 'numbers' is not defined
>>> for i in number:
	item.add(i)

	
Traceback (most recent call last):
  File "<pyshell#204>", line 2, in <module>
    item.add(i)
AttributeError: 'dict' object has no attribute 'add'
>>> itm = set()
>>> for i in number:
	itm.add(i)

	
>>> counter = 0
>>> for j in itm:
	counter = 0
	for i in number:
		if i is in j:
			
SyntaxError: invalid syntax
>>> for j in itm:
	for i in number:
		if i in j:
			counter+=1
		else:
			print("Occurence of character %j in String %s is %d" %(j,number,counter)

KeyboardInterrupt
>>> freq = dict()
>>> number = input("Enter a number")
Enter a number123456432345643
>>> for i in number:
	if i in freq:
	else:
		
SyntaxError: expected an indented block
>>> for i in number:
	if i in freq:
		
	else:
		
SyntaxError: expected an indented block
>>> for i in number:
	if i in freq:
		freq[i]+=1
	else:
		freq[i]=1
print(freq)
SyntaxError: invalid syntax
>>> for i in number:
	if i in freq:
		freq[i]+=1
	else:
		freq[i]=1
print(freq)
SyntaxError: invalid syntax
>>> freq = dict()
>>> for i in number:
	if i in freq:
		freq[i]+=1
	else:
		freq[i]=1

>>> for i in number:
	if i in freq:
		freq[i]+=1
	else:
		freq[i]=1
print(freq)
SyntaxError: invalid syntax
>>> for i in number:
	if i in freq:
		freq[i]+=1
	else:
		freq[i]=1
else :
	print(freq)

	
{'1': 2, '2': 4, '3': 8, '4': 8, '5': 4, '6': 4}
>>> # Find first and last digit in a number
>>> number = input("Enter a number ")
Enter a number 123456
>>> first_number = number[0]
>>> last_number = number[len(number)-1]
>>> first_number
'1'
>>> last_number
'6'
>>> # sum of first and last digit of a number
>>> number = input("Enter a number")
Enter a number12345678
>>> sum = int(number[0]) + int(number[len(number)-1])
>>> print(sum)
9
>>> 
>>> # Swap first and last digit of a number
>>> number = input("Enter a number:- ")
Enter a number:- 123456
>>> temp = number[0]
>>> number[0] = number[len(number)-1]
Traceback (most recent call last):
  File "<pyshell#283>", line 1, in <module>
    number[0] = number[len(number)-1]
TypeError: 'str' object does not support item assignment
>>> integerNum = int(number)
>>> counter = 1
>>> number = input("Enter a number: - ")
Enter a number: - 12345
>>> temp = number[0]
>>> temp2 = number[len(number)-1]
>>> number3 = temp2 + number[1:len(number)-1:1] + temp
>>> number3
'52341'
>>> temp2
'5'
>>> number = input("Enter a number:- ")
Enter a number:- 123456
>>> number[0]
'1'
>>> number[len(number)]
Traceback (most recent call last):
  File "<pyshell#296>", line 1, in <module>
    number[len(number)]
IndexError: string index out of range
>>> number = input("Enter a number:- ")
KeyboardInterrupt
>>> number[len(number)-1]
'6'
>>> temp = number[0]
>>> temp2 = number[len(number) - 1]
>>> number[1:len(number)-1:1]
'2345'
>>> number3 = temp2 + number[1:len(number)-1:1] + temp
>>> number3
'623451'
>>> # Sum of digits of a number:
>>> number = input("Please enter the number: - ")
Please enter the number: - 123456
>>> sum = 0
>>> for i in number:
	sum+=int(i)
else:
	print(sum)

	
21
>>> #Sum of product of digits of a number
>>> number = input("Please enter the number:-")
Please enter the number:-123456
>>> sum = 0
>>> for i in number:
	sum+= int(i)**2
else:
	print(sum)

	
91
>>> sum = 0
>>> number = 21
>>> for i in number:
	sum+= int(i)**2
else:
	print(sum)

	
Traceback (most recent call last):
  File "<pyshell#324>", line 1, in <module>
    for i in number:
TypeError: 'int' object is not iterable
>>> number = "21"
>>> for i in number:
	sum+= int(i)**2
else:
	print(sum)

	
5
>>> # Enter number in reverese
>>> number = input("Enter a number:- ")
Enter a number:- 123456
>>> reverseNumer = number[len(number)-1:0:-1]
>>> reverseNumber
Traceback (most recent call last):
  File "<pyshell#331>", line 1, in <module>
    reverseNumber
NameError: name 'reverseNumber' is not defined
>>> reverseNumer
'65432'
>>> reverseNumer = number[len(number):0:-1]
>>> reverseNumer
'65432'
>>> reverseNumer = number[len(number):-1:-1]
>>> reverseNumer
''
>>> number = input("Enter a number :- ")
Enter a number :- 123456
>>> reverseString = ""
>>> reverseString = number[0:len(number):-1]
>>> revesreString
Traceback (most recent call last):
  File "<pyshell#340>", line 1, in <module>
    revesreString
NameError: name 'revesreString' is not defined
>>> reverseString
''
>>> reverseString = number[len(number):]
>>> reverseString
''
>>> reverseString = number[len(number):0:-1]
>>> reverseString
'65432'
>>> dir(str)
['__add__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getnewargs__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mod__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmod__', '__rmul__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'capitalize', 'casefold', 'center', 'count', 'encode', 'endswith', 'expandtabs', 'find', 'format', 'format_map', 'index', 'isalnum', 'isalpha', 'isascii', 'isdecimal', 'isdigit', 'isidentifier', 'islower', 'isnumeric', 'isprintable', 'isspace', 'istitle', 'isupper', 'join', 'ljust', 'lower', 'lstrip', 'maketrans', 'partition', 'replace', 'rfind', 'rindex', 'rjust', 'rpartition', 'rsplit', 'rstrip', 'split', 'splitlines', 'startswith', 'strip', 'swapcase', 'title', 'translate', 'upper', 'zfill']
>>> number = input("Enter a String:- ")
Enter a String:- 123456
>>> str = ""
>>> str = number[::-1]
>>> str
'654321'
>>> number = input("Enter a number: - ")
Enter a number: - 123456
>>> reverseNumber = number[::-1]
>>> if number == reverseNumber :
	print("%s is palindrome: " %(number))
else:
	print("%s is not palindrom" %(number))

	
123456 is not palindrom
>>> number = 121
>>> reverseNumber = number[::-1]
Traceback (most recent call last):
  File "<pyshell#360>", line 1, in <module>
    reverseNumber = number[::-1]
TypeError: 'int' object is not subscriptable
>>> number = "121"
>>> reverseNumber = number[::-1]
>>> if number == reverseNumber :
	print("%s is palindrome: " %(number))
else:
	print("%s is not palindrom" %(number))

	
121 is palindrome: 
>>> # Print power or each number using loop
>>> counter = 0
>>> while counter < 256
SyntaxError: invalid syntax
>>> while counter < 256:
	print("ASCII Value of %d is " %(counter) + chr(counter))

	
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
ASCII Value of 0 is  
Traceback (most recent call last):
  File "<pyshell#370>", line 2, in <module>
    print("ASCII Value of %d is " %(counter) + chr(counter))
KeyboardInterrupt
>>> while counter <= 256:
	counter+=1
	print("ASCII Value of %d is " %(counter) + chr(counter))

	
ASCII Value of 1 is 
ASCII Value of 2 is 
ASCII Value of 3 is 
ASCII Value of 4 is 
ASCII Value of 5 is 
ASCII Value of 6 is 
ASCII Value of 7 is 
ASCII Value of 8 is 
ASCII Value of 9 is 	
ASCII Value of 10 is 

ASCII Value of 11 is 
ASCII Value of 12 is 
ASCII Value of 13 is 
ASCII Value of 14 is 
ASCII Value of 15 is 
ASCII Value of 16 is 
ASCII Value of 17 is 
ASCII Value of 18 is 
ASCII Value of 19 is 
ASCII Value of 20 is 
ASCII Value of 21 is 
ASCII Value of 22 is 
ASCII Value of 23 is 
ASCII Value of 24 is 
ASCII Value of 25 is 
ASCII Value of 26 is 
ASCII Value of 27 is 
ASCII Value of 28 is 
ASCII Value of 29 is 
ASCII Value of 30 is 
ASCII Value of 31 is 
ASCII Value of 32 is  
ASCII Value of 33 is !
ASCII Value of 34 is "
ASCII Value of 35 is #
ASCII Value of 36 is $
ASCII Value of 37 is %
ASCII Value of 38 is &
ASCII Value of 39 is '
ASCII Value of 40 is (
ASCII Value of 41 is )
ASCII Value of 42 is *
ASCII Value of 43 is +
ASCII Value of 44 is ,
ASCII Value of 45 is -
ASCII Value of 46 is .
ASCII Value of 47 is /
ASCII Value of 48 is 0
ASCII Value of 49 is 1
ASCII Value of 50 is 2
ASCII Value of 51 is 3
ASCII Value of 52 is 4
ASCII Value of 53 is 5
ASCII Value of 54 is 6
ASCII Value of 55 is 7
ASCII Value of 56 is 8
ASCII Value of 57 is 9
ASCII Value of 58 is :
ASCII Value of 59 is ;
ASCII Value of 60 is <
ASCII Value of 61 is =
ASCII Value of 62 is >
ASCII Value of 63 is ?
ASCII Value of 64 is @
ASCII Value of 65 is A
ASCII Value of 66 is B
ASCII Value of 67 is C
ASCII Value of 68 is D
ASCII Value of 69 is E
ASCII Value of 70 is F
ASCII Value of 71 is G
ASCII Value of 72 is H
ASCII Value of 73 is I
ASCII Value of 74 is J
ASCII Value of 75 is K
ASCII Value of 76 is L
ASCII Value of 77 is M
ASCII Value of 78 is N
ASCII Value of 79 is O
ASCII Value of 80 is P
ASCII Value of 81 is Q
ASCII Value of 82 is R
ASCII Value of 83 is S
ASCII Value of 84 is T
ASCII Value of 85 is U
ASCII Value of 86 is V
ASCII Value of 87 is W
ASCII Value of 88 is X
ASCII Value of 89 is Y
ASCII Value of 90 is Z
ASCII Value of 91 is [
ASCII Value of 92 is \
ASCII Value of 93 is ]
ASCII Value of 94 is ^
ASCII Value of 95 is _
ASCII Value of 96 is `
ASCII Value of 97 is a
ASCII Value of 98 is b
ASCII Value of 99 is c
ASCII Value of 100 is d
ASCII Value of 101 is e
ASCII Value of 102 is f
ASCII Value of 103 is g
ASCII Value of 104 is h
ASCII Value of 105 is i
ASCII Value of 106 is j
ASCII Value of 107 is k
ASCII Value of 108 is l
ASCII Value of 109 is m
ASCII Value of 110 is n
ASCII Value of 111 is o
ASCII Value of 112 is p
ASCII Value of 113 is q
ASCII Value of 114 is r
ASCII Value of 115 is s
ASCII Value of 116 is t
ASCII Value of 117 is u
ASCII Value of 118 is v
ASCII Value of 119 is w
ASCII Value of 120 is x
ASCII Value of 121 is y
ASCII Value of 122 is z
ASCII Value of 123 is {
ASCII Value of 124 is |
ASCII Value of 125 is }
ASCII Value of 126 is ~
ASCII Value of 127 is 
ASCII Value of 128 is 
ASCII Value of 129 is 
ASCII Value of 130 is 
ASCII Value of 131 is 
ASCII Value of 132 is 
ASCII Value of 133 is 
ASCII Value of 134 is 
ASCII Value of 135 is 
ASCII Value of 136 is 
ASCII Value of 137 is 
ASCII Value of 138 is 
ASCII Value of 139 is 
ASCII Value of 140 is 
ASCII Value of 141 is 
ASCII Value of 142 is 
ASCII Value of 143 is 
ASCII Value of 144 is 
ASCII Value of 145 is 
ASCII Value of 146 is 
ASCII Value of 147 is 
ASCII Value of 148 is 
ASCII Value of 149 is 
ASCII Value of 150 is 
ASCII Value of 151 is 
ASCII Value of 152 is 
ASCII Value of 153 is 
ASCII Value of 154 is 
ASCII Value of 155 is 
ASCII Value of 156 is 
ASCII Value of 157 is 
ASCII Value of 158 is 
ASCII Value of 159 is 
ASCII Value of 160 is  
ASCII Value of 161 is ¡
ASCII Value of 162 is ¢
ASCII Value of 163 is £
ASCII Value of 164 is ¤
ASCII Value of 165 is ¥
ASCII Value of 166 is ¦
ASCII Value of 167 is §
ASCII Value of 168 is ¨
ASCII Value of 169 is ©
ASCII Value of 170 is ª
ASCII Value of 171 is «
ASCII Value of 172 is ¬
ASCII Value of 173 is ­
ASCII Value of 174 is ®
ASCII Value of 175 is ¯
ASCII Value of 176 is °
ASCII Value of 177 is ±
ASCII Value of 178 is ²
ASCII Value of 179 is ³
ASCII Value of 180 is ´
ASCII Value of 181 is µ
ASCII Value of 182 is ¶
ASCII Value of 183 is ·
ASCII Value of 184 is ¸
ASCII Value of 185 is ¹
ASCII Value of 186 is º
ASCII Value of 187 is »
ASCII Value of 188 is ¼
ASCII Value of 189 is ½
ASCII Value of 190 is ¾
ASCII Value of 191 is ¿
ASCII Value of 192 is À
ASCII Value of 193 is Á
ASCII Value of 194 is Â
ASCII Value of 195 is Ã
ASCII Value of 196 is Ä
ASCII Value of 197 is Å
ASCII Value of 198 is Æ
ASCII Value of 199 is Ç
ASCII Value of 200 is È
ASCII Value of 201 is É
ASCII Value of 202 is Ê
ASCII Value of 203 is Ë
ASCII Value of 204 is Ì
ASCII Value of 205 is Í
ASCII Value of 206 is Î
ASCII Value of 207 is Ï
ASCII Value of 208 is Ð
ASCII Value of 209 is Ñ
ASCII Value of 210 is Ò
ASCII Value of 211 is Ó
ASCII Value of 212 is Ô
ASCII Value of 213 is Õ
ASCII Value of 214 is Ö
ASCII Value of 215 is ×
ASCII Value of 216 is Ø
ASCII Value of 217 is Ù
ASCII Value of 218 is Ú
ASCII Value of 219 is Û
ASCII Value of 220 is Ü
ASCII Value of 221 is Ý
ASCII Value of 222 is Þ
ASCII Value of 223 is ß
ASCII Value of 224 is à
ASCII Value of 225 is á
ASCII Value of 226 is â
ASCII Value of 227 is ã
ASCII Value of 228 is ä
ASCII Value of 229 is å
ASCII Value of 230 is æ
ASCII Value of 231 is ç
ASCII Value of 232 is è
ASCII Value of 233 is é
ASCII Value of 234 is ê
ASCII Value of 235 is ë
ASCII Value of 236 is ì
ASCII Value of 237 is í
ASCII Value of 238 is î
ASCII Value of 239 is ï
ASCII Value of 240 is ð
ASCII Value of 241 is ñ
ASCII Value of 242 is ò
ASCII Value of 243 is ó
ASCII Value of 244 is ô
ASCII Value of 245 is õ
ASCII Value of 246 is ö
ASCII Value of 247 is ÷
ASCII Value of 248 is ø
ASCII Value of 249 is ù
ASCII Value of 250 is ú
ASCII Value of 251 is û
ASCII Value of 252 is ü
ASCII Value of 253 is ý
ASCII Value of 254 is þ
ASCII Value of 255 is ÿ
ASCII Value of 256 is Ā
ASCII Value of 257 is ā
>>> # 19. Write a Python program to find power of a each number using for loop.
>>> number = input("Please enter the number: -")
Please enter the number: -123
>>> str = ""
>>> for i in number:
	str+= int(i)**2
else:
	print("power of a each number is:- %s" %(str))

	
Traceback (most recent call last):
  File "<pyshell#381>", line 2, in <module>
    str+= int(i)**2
TypeError: can only concatenate str (not "int") to str
>>> for i in number:
	str+= str(int(i)**2)
else:
	print("power of a each number is:- %s" %(str))

	
Traceback (most recent call last):
  File "<pyshell#383>", line 2, in <module>
    str+= str(int(i)**2)
TypeError: 'str' object is not callable
>>> for i in number:
	str2+= str(int(i)**2)
else:
	print("power of a each number is:- %s" %(str2))

	
Traceback (most recent call last):
  File "<pyshell#385>", line 2, in <module>
    str2+= str(int(i)**2)
NameError: name 'str2' is not defined
>>> str2 = ""
>>> for i in number:
	str2+= str(int(i)**2)
else:
	print("power of a each number is:- %s" %(str2))

	
Traceback (most recent call last):
  File "<pyshell#388>", line 2, in <module>
    str2+= str(int(i)**2)
TypeError: 'str' object is not callable
>>> str2 = ""
>>> str3 = str(int(2)**2)
Traceback (most recent call last):
  File "<pyshell#391>", line 1, in <module>
    str3 = str(int(2)**2)
TypeError: 'str' object is not callable
>>> str3 = str((int(2)**2))
Traceback (most recent call last):
  File "<pyshell#392>", line 1, in <module>
    str3 = str((int(2)**2))
TypeError: 'str' object is not callable
>>> 
