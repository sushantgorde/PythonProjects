Python 3.7.3 (v3.7.3:ef4ec6ed12, Mar 25 2019, 22:22:05) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> name = (1,2, [1,2,3,4])
>>> name[2][1] = 45
>>> name
(1, 2, [1, 45, 3, 4])
>>> #Conditional statements - Python has only if-else
number = int(input("Enter a number"))
Enter a number5
>>> if number % 2 == 1
SyntaxError: invalid syntax
>>> if number % 2 == 1 :
	print("This is a executable statement")
	print("Number %d is odd" %(number))
else :
	print("Inside Else")
	print("%d number is even")

	
This is a executable statement
Number 5 is odd

>>> # Standard we should have 4 spaces
>>> if number % 2 == 1 : # Conditional operator returning boolea



	
KeyboardInterrupt
>>> 
#Number - 0, 0.0, 0j = false
>>> #String - "", '' -> False
>>> #List - [] -> False
>>> # Dic {}
>>> #Dict {} -> False
>>> #Tuple - () -> False
>>> #Set = {} -> False
>>> #None -> False
>>> 
obj = (0)
>>> if obj :
	print(True)

	
>>> if obj :
	print(True)
else
SyntaxError: invalid syntax
>>> if obj :
	print(True)
else:
	print(False)

	
False
>>> obj = (0,)
>>> if obj :
	print(True)
else :
	print(False)

	
True
>>> name = {1,2,3}
>>> name
{1, 2, 3}
>>> type(name)
<class 'set'>
>>> obj = None
>>> type(obj)
<class 'NoneType'>
>>> #synatx 2 - return value if TRUE else return different value
>>> obj = (0,)
>>> print(True) if obj else False
True
>>> #This is applicable only for single line of execution
>>> numbers = list(range(10))
>>> if len(numbers) > 5:
	print("Total number of objects we have in list are greater than 5")
	# This is inner block - called as nested block
	if(numbers[0] % 2 == 1
	   print("First number in list is odd")
	   
SyntaxError: invalid syntax
>>> if len(numbers) > 5:
	print("Total number of objects we have in list are greater than 5")
	# This is inner block - called as nested block
	if(numbers[0] % 2 == 1 :
	   print("First number in list is odd")
	   
SyntaxError: invalid syntax
>>> if len(numbers) > 5:
	print("Total number of objects we have in list are greater than 5")
	# This is inner block - called as nested block
	if(numbers[0] % 2 == 1 :
	   print("First number in list is odd")
	   
SyntaxError: invalid syntax
>>> if len(numbers) > 5:
	print("Total number of objects we have in list are greater than 5")
	# This is inner block - called as nested block
	if(numbers[0] % 2 == 1 :
	   print("First number in list is odd") else:
	   
SyntaxError: invalid syntax
>>> if len(numbers) > 5:
	print("Total number of objects we have in list are greater than 5")
	# This is inner block - called as nested block
	if(numbers[0] % 2 == 1 :
	   print("First number in list is odd")
	   
SyntaxError: invalid syntax
>>> if len(numbers) > 5:
	print("Total number of objects we have in list are greater than 5")
	# This is inner block - called as nested block
	if numbers[0] % 2 == 1 :
	   print("First number in list is odd")
	else:
		print("Number in list is even")

Total number of objects we have in list are greater than 5
Number in list is even
>>> var = 10 and 0
>>> var
0
>>> var = 0 or 10 #??
>>> var
10
>>> var = 30 or 0 #??
>>> var
30
>>> if len(numbers) > 5 and numbers[0] % 2 == 0:
	print("Total number of objects we have in list are greater than 5 and Number in list is even")

	
Total number of objects we have in list are greater than 5 and Number in list is even
>>> if not len(numbers) > 5 and numbers[0] % 2 == 0:
	print("Total number of objects we have in list are greater than 5 and Number in list is even")

	
>>> if not len(numbers) > 5 and numbers[0] % 2 == 0 && len(numbers) / 2 == 5:
	
SyntaxError: invalid syntax
>>> if not len(numbers) > 5 and numbers[0] % 2 == 0 and len(numbers) / 2 == 5:
	print("Total number of objects we have in list are greater than 5 and Number in list is even")

	
>>> if not (len(numbers) > 5 or numbers[0] % 2 == 0 and len(numbers)/ 2 == 5)
SyntaxError: invalid syntax
>>> if not (len(numbers) > 5 or numbers[0] % 2 == 0 and len(numbers)/ 2 == 5) :
	print("Total number of objects we have in list are greater than 5 and Number in list is even")

	
>>> # Logical opr
>>> # and, or, not
>>> # and
>>> #True and True -> True
>>> numbers = list ( range (10))
>>> numbers
[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
>>> numbers[2]
2
>>> #Syntax if elif elif...else
>>> numbers = list(range(10))
>>> if(len(numbers) > 10 :
   
SyntaxError: invalid syntax
>>> if len(numbers) > 10 :
	print("numbers length is greater than 10")
	elif len(numbers) < 10 :
		
SyntaxError: invalid syntax
>>> if len(numbers) > 10 :
	print("numbers length is greater than 10")
elif len(numbers) < 10 :
	print("Numbers length is less than 10")
elif len(numbers) == 10
SyntaxError: invalid syntax
>>> if len(numbers) > 10 :
	print("numbers length is greater than 10")
elif len(numbers) < 10 :
	print("Numbers length is less than 10")
elif len(numbers) == 10 :
	print("Numbers length is equal to 10")

	
Numbers length is equal to 10
>>> # Loops
>>> counter = 0
>>> while count <= 10
SyntaxError: invalid syntax
>>> while counter <= 10:
	print(counter)
	counter += 1

	
0
1
2
3
4
5
6
7
8
9
10
>>> while counter <= 10:
	print(counter)
	counter += 1
else:
	print("Executes when condition is false")

	
Executes when condition is false
>>> counter = 0
>>> while counter <= 10:
	print(counter)
	counter += 1
else:
	print("Executes when condition is false")

	
0
1
2
3
4
5
6
7
8
9
10
Executes when condition is false
>>> #WAP to find out first 10 odd numbers
>>> counter = 1
>>> number = 1
>>> while counter <= 10
SyntaxError: invalid syntax
>>> while counter <=10:
	print(number)
	number+=2
	counter++
	
SyntaxError: invalid syntax
>>> while counter <=10:
	print(number)
	number+=2
	counter+=1

	
1
3
5
7
9
11
13
15
17
19
>>> number = 1
>>> counter = 1
>>> while number % 2 == 1 and counter <=10 :
	print(number)
	number+= 2
	counter+=1

	
1
3
5
7
9
11
13
15
17
19
>>> range1 = range(10,1)
>>> range1
range(10, 1)
>>> range[3]
Traceback (most recent call last):
  File "<pyshell#139>", line 1, in <module>
    range[3]
TypeError: 'type' object is not subscriptable
>>> range1[5]
Traceback (most recent call last):
  File "<pyshell#140>", line 1, in <module>
    range1[5]
IndexError: range object index out of range
>>> type(range1)
<class 'range'>
>>> dir(range1)
['__bool__', '__class__', '__contains__', '__delattr__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__gt__', '__hash__', '__init__', '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__reversed__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'count', 'index', 'start', 'step', 'stop']
>>> range(1,20,2)
range(1, 20, 2)
>>> counter = int(input("Please Enter Number"))
Please Enter Number25
>>> start = 1
>>> while counter >= 0
SyntaxError: invalid syntax
>>> while counter >=0 :
	print(start)
	counter-=1
	start+=1

	
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
>>> # Print first n natural numbers
>>> counter = int(input("Please Enter Numbers to be printed in reverse order :"))
Please Enter Numbers to be printed in reverse order :30
>>> while counter >=0
SyntaxError: invalid syntax
>>> while counter >= 0:
	print(counter)
	counter-=1

	
30
29
28
27
26
25
24
23
22
21
20
19
18
17
16
15
14
13
12
11
10
9
8
7
6
5
4
3
2
1
0
>>> chr(74)
'J'
>>> chr(65)
'A'
>>> counter = 26
>>> start = 97
>>> while counter >=0:
	print(char(start))
	start+=1
	counter-=1

	
Traceback (most recent call last):
  File "<pyshell#167>", line 2, in <module>
    print(char(start))
NameError: name 'char' is not defined
>>> while counter >=0:
	print(chr(start))
	start+=1
	counter-=1

	
a
b
c
d
e
f
g
h
i
j
k
l
m
n
o
p
q
r
s
t
u
v
w
x
y
z
{
>>> while counter >=1:
	print(char(start))
	start+=1
	counter-=1

	
>>> start = 97
>>> counter = 10
>>>  while counter >=1:
	print(char(start))
	start+=1
	counter-=1
	
SyntaxError: unexpected indent
>>> while counter >=1:
	print(char(start))
	start+=1
	counter-=1

	
Traceback (most recent call last):
  File "<pyshell#176>", line 2, in <module>
    print(char(start))
NameError: name 'char' is not defined
>>> while counter >=1:
	print(chr(start))
	start+=1
	counter-=1

	
a
b
c
d
e
f
g
h
i
j
>>> start = 97
>>> counter = 0
>>> counter = 26
>>> while counter >=1:
	print(chr(start))
	start+=1
	counter-=1

	
a
b
c
d
e
f
g
h
i
j
k
l
m
n
o
p
q
r
s
t
u
v
w
x
y
z
>>> counter = 0
>>> number = 0
>>> counter = 1
>>> while counter < 100:
	print(number)
	number+=2
	counter+=1

	
0
2
4
6
8
10
12
14
16
18
20
22
24
26
28
30
32
34
36
38
40
42
44
46
48
50
52
54
56
58
60
62
64
66
68
70
72
74
76
78
80
82
84
86
88
90
92
94
96
98
100
102
104
106
108
110
112
114
116
118
120
122
124
126
128
130
132
134
136
138
140
142
144
146
148
150
152
154
156
158
160
162
164
166
168
170
172
174
176
178
180
182
184
186
188
190
192
194
196
>>> while number < 100:
	print(number)
	number+=2

	
>>> number = 0
>>> while number < 100:
	print(number)
	number+=2

	
0
2
4
6
8
10
12
14
16
18
20
22
24
26
28
30
32
34
36
38
40
42
44
46
48
50
52
54
56
58
60
62
64
66
68
70
72
74
76
78
80
82
84
86
88
90
92
94
96
98
>>> numbers = 1
>>> while number < 100:
	if number % 2 == 1:
		print(number)
		number+=1

	
>>> number = 1
>>> while number < 100:
	if number % 2 == 1:
		print(number)
		number+=1

		
1
Traceback (most recent call last):
  File "<pyshell#204>", line 1, in <module>
    while number < 100:
KeyboardInterrupt

>>> number = 1
>>> while number % 2 == 1 and number < 100
SyntaxError: invalid syntax
>>> while number % 2 == 1 and number < 100:
	print(number)

	
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
Traceback (most recent call last):
  File "<pyshell#209>", line 2, in <module>
    print(number)
KeyboardInterrupt
>>> while number < 100:
	if number % 2 == 1:
		print(number)
	number+=1

	
1
3
5
7
9
11
13
15
17
19
21
23
25
27
29
31
33
35
37
39
41
43
45
47
49
51
53
55
57
59
61
63
65
67
69
71
73
75
77
79
81
83
85
87
89
91
93
95
97
99
>>> # Sum of natural numbers between 1 to n
>>> number = int(input("Please Enter natural number: "))
Please Enter natural number: 40
>>> sum = 0
>>> start = 0
>>> while start <= number :
	sum+= start
	start++
	
SyntaxError: invalid syntax
>>> while start <= number :
	sum+= start
	start+=1
print(sum)
SyntaxError: invalid syntax
>>> start = 0
>>> sum = 0
>>> while start <= number
SyntaxError: invalid syntax
>>> while start < = number:
	
SyntaxError: invalid syntax
>>> while start <= number :
	sum+= start

	
Traceback (most recent call last):
  File "<pyshell#228>", line 1, in <module>
    while start <= number :
KeyboardInterrupt
>>> 
KeyboardInterrupt
>>> start = 1
>>> sum = 0
>>> while start <= number:
	sum+=start
	start+= 1
else :
	print(sum)

	
820
>>> number = int(input("Enter number to do some of even numbers :"))
Enter number to do some of even numbers :50
>>> sum = 0
>>> start = 0
>>> counter = 0
>>> while counter < number :
	sum+=start
	start+=2
	counter+=1
else :
	print(sum)

	
2450
>>> sum = 0
>>> start = 0
>>> counter = 0
>>> start = 1
>>> while counter < number :
	sum+=start
	start+=2
	counter+=1
else :
	print(sum)

	
2500
>
