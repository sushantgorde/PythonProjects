from builtins import print
from builtins import range

__author__ = '308966'
from Custom_Module import MyModule

print('Program started')

var1 = 10
var2 = 20

def func(a,b):
    print("Inside function definition")
    return a+b

for i in range(2):
    print('Inside loop')
    print(i)

c = func(var1,var2)
print('After function call:- ',c)

d = MyModule.add(var1,var2)
print(d)

print('Program completed')