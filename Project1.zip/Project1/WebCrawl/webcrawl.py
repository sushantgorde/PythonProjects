__author__ = '308966'
import requests
import re

baseurl = 'https://www.nseindia.com/live_market/dynaContent/live_watch/get_quote/GetQuote.jsp?symbol='

symbols = ['TCS', 'INFY', 'WIPRO']

for symbol in symbols:
    url = baseurl+symbol
    content = requests.get(url).text
    for line in content.split('\n'):
        line = line.strip()
        if line.startswith('{"tradedDate"'):
            match = re.search('.*"lastPrice"(.*)"}]', line)
            if match:
                print(match.group(1))



