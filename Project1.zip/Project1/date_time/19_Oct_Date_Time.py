__author__ = '308966'
from datetime import datetime
import calendar
datetime1 = datetime.today()
#Print only todays date i.e. 19
print(datetime1.day)
print(datetime1.strftime('%A'))
#strftime = Converts python date into string

days =["Monday", "Tuesday", "Wednesday", "Thursday",
                         "Friday", "Saturday", "Sunday"]

#Try to find out what is day today i.e. Saturday
print(days[datetime1.weekday()])

#strptime - Converts string into python understandable date
#Find out day on 27th October
date = '20191027'
datetime_2 = datetime.strptime(date, '%Y%m%d')
print(datetime_2.strftime("%A"))
print(datetime_2)

#Find out day on your birthday
date2 = '20191125'
datetime_2 = datetime.strptime(date2, '%Y%m%d')

print(datetime_2.strftime("%A"))
print(datetime_2.strftime("%d"))
print(datetime_2.strftime("%m"))
print(datetime_2.strftime("%Y"))

