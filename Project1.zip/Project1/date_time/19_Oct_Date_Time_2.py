#!/usr/bin/env python
# coding: utf-8

# In[9]:


#Try and find out today's date i.e. 19
#Try to find out what is day today i.e. Saturday
#Try to find out what is day on 27th October
#Try to find out Birthday in this year
from datetime import datetime
print(datetime.today().strftime('%d'))
print(datetime.today().strftime('%m'))
print(datetime.today().strftime('%A'))


# In[2]:


from datetime import datetime
from datetime import timedelta

current_date = datetime.now()
construct_date = datetime(2019,1,1,0,0,0,0) #Year, Month, Day, HH, MM, SS, MS

#compare two same types of object using >., < , <=, >=
print(current_date > construct_date)
print(current_date- construct_date)

one_day = timedelta(days=1) #OneDay
print(current_date+one_day) #__add__
print(current_date-one_day) # __sub__


# In[14]:


import datetime

date2 = '20191125'
datetime_2 = datetime.datetime.strptime(date2, '%Y%m%d')

print(datetime_2.strftime("%A"))
print(datetime_2.strftime("%d"))
print(datetime_2.strftime("%m"))
print(datetime_2.strftime("%Y"))


# In[ ]:





# In[ ]:




