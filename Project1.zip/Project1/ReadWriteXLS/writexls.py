__author__ = '308966'

import xlwt

book = xlwt.Workbook()
sheet1 = book.add_sheet('Names')
sheet1.write(0,0,'ID')
sheet1.write(0,1,'Name')

sheet1.write(1,0,'Sushant')
sheet1.write(1,1,'1')

sheet1.write(2,0,'Trupti')
sheet1.write(2,1,'2')

sheet2 = book.add_sheet('Courses')
sheet2.write(0,0,'ID')
sheet2.write(0,1,'Courses')

sheet2.write(1,0,1)
sheet2.write(1,1,'Python')

sheet2.write(2,0,2)
sheet2.write(2,1,'Java')

book.save('D:\PythonProjects\Write.xls')


