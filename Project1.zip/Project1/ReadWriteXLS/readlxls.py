__author__ = '308966'
import xlrd
import xlwt

book = xlrd.open_workbook('D:\PythonProjects\Students.xlsx')
for sheet in book.sheets():
    print(sheet.name)
    for row in range(sheet.nrows):
        for col in range(sheet.ncols):
            print("Value at row {} col {} has data value {}".format(row,col,sheet.cell_value(row,col)))


