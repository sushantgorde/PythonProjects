#!/usr/bin/env python
# coding: utf-8

# # Regular Expressions

# In[8]:


import re

string = "This is my sample string"
match = re.match('This',string,flags= re.I) # re.I is mentioned to allow case insensitive

if match:
    print(match.start()) # At which index pattern is found
    print(match.end()) # At which index pattern ends
    print(match.group()) # returns which pattern matched in string
    print(match.span()) # Start and end index of a pattern
else:
    print('Pattern not found....')

type(match)
    
# Patterns are case sensitive


# In[5]:


help(re.match)


# In[9]:


help(re.search)


# In[10]:


import re

string = "This is my sample string"
match = re.search('is',string,flags= re.I) # re.I is mentioned to allow case insensitive

if match:
    print(match.start()) # At which index pattern is found
    print(match.end()) # At which index pattern ends
    print(match.group()) # returns which pattern matched in string
    print(match.span()) # Start and end index of a pattern
else:
    print('Pattern not found....')

type(match)
    
# Patterns are case sensitive


# In[11]:


help(re.finditer)


# In[13]:


import re

string = "This is my sample string"
matches = re.finditer('is',string,flags= re.I) # re.I is mentioned to allow case insensitive

for match in matches:
    print(match.start()) # At which index pattern is found
    print(match.end()) # At which index pattern ends
    print(match.group()) # returns which pattern matched in string
    print(match.span()) # Start and end index of a pattern

type(match)


# In[14]:


help(re.findall)


# In[16]:


import re

string = "This is my sample string"
matches = re.findall('is',string,flags= re.I) # re.I is mentioned to allow case insensitive

print(matches)


# In[18]:


#Using pattern object, Patterns can also be compiled first and then used again

import re

string = "This is my sample string"
pattern = re.compile('is',flags = re.I)
match = pattern.search(string) # re.I is mentioned to allow case insensitive

if match:
    print(match.start()) # At which index pattern is found
    print(match.end()) # At which index pattern ends
    print(match.group()) # returns which pattern matched in string
    print(match.span()) # Start and end index of a pattern

type(match)


# In[ ]:


# Wild Card characters

. : a dot or period (it match anything except \n)
\ : backslash - it hides/suppress special meaning of wildcard
[]: - Character class
[^]: - Negate character class
{m,n} - minimum m occurences and max n occurences
get_ipython().run_line_magic('pinfo', '')
* - Similar to {0,}
+ - similar to {1,}
[a-zA-Z0-9] - Similar to \w
[0-9] - \d
[ \t\n] - \s

example - 
a.b - a followed by anything followed by b
a..b - a floowed by anything followed by anything followed by b
a\..b - a followed by . followed by b (meaning of . is suppressed)


# In[23]:


import re 

string = 'This string contains number 101 and IP 10.11.12.13'

match = re.search('..',string) # Will return first two characters of string
if match: 
    print(match.group())
    
match = re.search('10.',string) # Returns 101
if match: 
    print(match.group())
    
match = re.search('.1',string) # Returns Space and 1
if match: 
    print(match.group())

match = re.search('10\..',string) # Returns 10.1, means meaning of first . is suppressed
if match: 
    print(match.group())
    
match = re.search('.ing',string) # Returns ring
if match: 
    print(match.group())

match = re.search('..tains',string) # Returns ring
if match: 
    print(match.group())


# In[26]:


import re 

def refind(pat, string):
    match = re.search(pat,string)
    if match:
        print(match.group())
    else:
        print("Pattern not found")
        
        
string = 'this string contains number 101 and IP 10.11.12.13'

refind('[a-z]',string) # Will return 't', first character found matchiing pattern [a-z]
refind('[0-9]',string) # Will return 1, first character found matchiing pattern [0-9]
refind('[a-z0-9]',string) # Will return I, first character found matchiing pattern [a-z0-9]
refind('[a-zA-Z0-9]',string) # Will return ., first character matching
refind('[0-9][0-9]\.[0-9][0-9]\.[0-9][0-9]\.[0-9][0-9]\.',string) # Returns IP address.


# In[37]:


# Write a program to accept a password from user and validate the following :
#1. Password should contain at least one character
#2. Password should contain at least one digit
#3. password should contain at least one special character
#4. Password length must be greater than eight

string = input("Please enter a password: - ")

pattern1 = re.compile('[a-zA-z]',flags = re.I)
pattern2 = re.compile('[0-9]',flags = re.I)
pattern3 = re.compile('[@#$%^&*]',flags = re.I)
match1 = pattern1.search(string) # re.I is mentioned to allow case insensitive
match2 = pattern2.search(string) # re.I is mentioned to allow case insensitive
match3 = pattern3.search(string) # re.I is mentioned to allow case insensitive

if match1 and match2 and match3 and len(string) > 8:
    print("Password meets the criteria")
else:
    print("Pattern doesnt meet the criteria")


# In[36]:



string = input("Please enter a password:-")

refind('[a-zA-Z][0-9][@#$&]',string)


# In[47]:


refind('.{1,3}', 'This is my string and number 101010110101') # Matches any characters min 1 and max 3 times
refind('[0-9]{1,5}','This is my string and number 101010110101') # Matches any digits min 1 and max 5 times
refind('[0-9]{1,5}', 'This is my string and 111 number 101010110101') # Matches any digits min 1 and max 5 times
#Output is 111, because it stops at first occurence of digits which meets criteria

refind('ab{0,5}','This is mybbbbb an aabbbbbbb string and 111 number is 101010101') #Matches for String which starts with a and cntains b min 0 or max 5 times
#Output will be a

refind('a(bc){1,5}','This is mybbbbb an aabcbcbcbcbbcb string and 111 number is 101010101') # Matches for string 'ab' 
#which occurs minimum 1 and max 5 times


# In[50]:


# Write a program to read a file which contains the IP Addresses and find out count of each and every IP Address in file
refind('[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+','This is an IP Address 101.102.103.104')


# In[57]:


# Write a program to read a file which contains the IP Addresses and find out count of each and every IP Address in file

import re

mydict = dict()

with open('D:\PythonProjects\\IP_Addresses.txt') as fileN:
    for line in fileN.readlines():
        line = line.strip()
        all_ips = re.findall('[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+',line)
        for ip in all_ips:
            if ip in mydict:
                mydict[ip]+=1
            else:
                mydict[ip] = 1


for key, value in mydict.items():
    print(key,value)


# In[63]:


# Write a program to read a file which contains the IP Addresses and find out count of each and every IP Address in file

import re

mydict = dict()

with open('D:\PythonProjects\\IP_Addresses.txt') as fileN:
    for line in fileN.readlines():
        line = line.strip()
        all_ips = re.finditer('([0-9]+)\.([0-9]+)\.([0-9]+)\.([0-9]+)',line)
        for match in all_ips:
            invalid = 0
            for ind_ip in match.groups():
                if(int(ind_ip) > 0 and int(ind_ip) <= 255):
                    pass
                else:
                    invalid = 1
            if invalid == 0:
                ip = match.group()
                if ip in mydict:
                    mydict[ip]+=1
                else:
                    mydict[ip] = 1
            else:
                print("Invalid IP is ", match.group())


for key, value in mydict.items():
    print(key,value)


# In[ ]:




