#!/usr/bin/env python
# coding: utf-8

# In[15]:


sorted(object, key=, reverse=)
print(sorted(employees,key=lambda x:x[1] if x[2]=='IT' else max_it, reverse=False)) #Built In Function


# In[45]:


# Write a program to find out unique distinct and duplicate numbers from a list
numbers = [10, 1, 1, 10, 20,30,40,50]
print(list(set(filter(lambda x : x if numbers.count(x) > 1 else None, numbers)))) # Dupolicate 
print(list(set(numbers))) # Distinct
print(list(filter(lambda x : x if numbers.count(x) == 1 else None , numbers))) #Unique

print({i for i in numbers if numbers.count(i) > 1})
print({i for i in numbers if numbers.count(i) == 1})


# In[44]:


#Find minimum salary of an employee belonging to IT Department
employees = [['aakash', 2000,'IT'],['Ankit',1500,'HR'],
            ['amit',1800,'IT'],['Ajay',1100,'HR']]
max_it = max(map(lambda x: x[1] if x[2] == 'IT' else 0,employees))
print(max_it)

employees.sort(key=lambda x:x[1] if x[2]=='IT' else max_it, reverse=False)
print(employees)


# In[12]:


#Find maximum salary of an employee belonging to IT Department

employees = [['aakash', 2000,'IT'],['Ankit',1500,'HR'],
            ['amit',1800,'IT'],['Ajay',1100,'HR']]
employees.sort(key=lambda x:x[1] if x[2]=='IT' else False, reverse=True)
print(employees[0])


# In[1]:


dir(list)
names = ["Sushant", "Trupti", "Spruha", "Shantanu","Ratnaveer","Yogesh"]


# In[1]:


numbers = [1,2,3,4,5]
numbers.extend("Python")
print(numbers)
numbers = [1,2,3,4,5]
numbers.append("Python")
print(numbers)

numbers = list() # Will change its memory id
numbers.clear() # Id remains same only element
del numbers # Deletes id from memory


# In[ ]:





# In[4]:


names = ['aakash', 'Ankit', 'amit','Ajay']
names.sort(key=lambda x:x.upper()) #Sort based on functions
print(names)

employees = [['aakash',2000],['Ankit',1500],['amit',1800],['Ajay',1100]]
employees.sort(key=lambda x:x[1])
print(employees)
help(map)


# In[32]:


names = ["Sushant", "Trupti", "Spruha","Spruha", "Shantanu","Ratnaveer","Yogesh"]
names2 = ["Test3","Test4","Test5"]
#help(list.append)
#names.append("Rajesh") # Appends object at the end of the list
#help(list.clear)
#names.clear() #Removes all elements from list
#help(list.copy)
#names2 = names.copy() # Returns shallow copy of list i.e. if we change in one list other list will not be changed
#names[0] = "Test"
#names3 = names # Deep copy
#names3[0] = "Test2"
#help(list.count)
#print(names.count("Spruha")) #Print number of times "Spruha Occured in list"
#help(list.extend)
#names.extend(names2) # Extend names by adding elements from names2 in the list
#help(list.index)
#print(names.index("Spruha")) # Returns index of  first occurence of "Spruha"
#help(list.insert) 
#names.insert(0,"TestInsert") # Inserts object before given index (in this case 0)
#help(list.pop)
#print(names.pop(2)) # Will return object at index position 2 and remove it from list
#help(list.remove)
#names.remove("Shantanu") # Removes first occurence of "Shantanu" from names list
#help(list.reverse)
#print(names.reverse()) #Reverse the contents of the list
#help(list.sort)
#names.sort() # Sorts the list in alphabetical order for strings
names.sorr(reverse=True) #Descending
print(names)


# sum1 = lambda x,y:x+y
# print(sum1)
