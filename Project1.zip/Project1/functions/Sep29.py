#!/usr/bin/env python
# coding: utf-8

# In[6]:


#Functions - Are set of instructions which you are reusable
#Types of functions 
#1. Builtin functions
#2. User Defined functions
#3. Class functions / Object functions

#def is used to start defining functions
#In python function has to be defined first before calling
def functionName():
    print('This is statement 1')
    print('This is statement 2')
    print('This is statement 3')
    if True:
        return 10
    else :
        return "Blalalala"
    print("This is dead code") # This is dead code and will not be executed as it is coming after return
  
functionName() # This is how we call the function
b = functionName() #This is how we call the function and accept return
print(b) #None, because function is not returning any value


# In[13]:


var = 20
def functionName(var): #var is local to function
    #Because preference is always given to local variable
    #If local variable is not present then preference is given to global
    print('This is statement 1', var)

functionName([1,2,3]) #Positional parameter
functionName(var = [1,2,3]) # Keyword parameter, This name should match to the name defined in definition
print(var) # This will print global variable


# In[14]:


var = 20
def func():
    var = 10 # Local variable overriding global variable
    print("This is statement",var)

func()
print(var) #This will print value 20


# In[17]:


var = 20
def func(var):
    global var # global is a keyword in python to define that you are referring to global object
    #But we cannot have both global and local 
    var = 10 # Local variable overriding global variable. This will give error
    print("This is statement",var)

func(var = 10)
print(var) #This will print value 20


# In[18]:


var = 10
def func():
    var = 20
    print('Inner 1 ', var)
    def func1():
        print('Inner 2',var)
    func1()

func()
print('Outside ', var)


# In[24]:


# Function taking n number of arguments
def func(*args):
    # *args is just a convention
    # * indicates that it can take n number of arguments
    print(args)

func()
func(10,20,[30,40])
func(10,20,30,40,50)


# In[22]:


# Default value to a variable
def func(var1, var2 = 10, var3= None) : #Python will not allow this
    print('This is statement ', var1)
    print('This is statement ', var2)
    print('This is statement ', var3)

func(10,20,30)
func(var1 = 10, var3=20)


# In[ ]:


def func(var1, var2 = 10, var3) : #Python will not allow this
    print('This is statement ', var1)
    print('This is statement ', var2)
    print('This is statement ', var3)
    

func(20,20,30)
func(var1 = 20,var3 = 30)
#Rule 3 - You cannot have a non default parameter after default parameter


# In[20]:


def func(var1,var2):
    print('This is statement ', var1)
    print('This is statement ', var2)

func(10,20)
func(var1 = 10, var2 = 30)
func(10, var2 = 20) # Allowed combination of first positional and then keyword parameter
func(var2 = 10, var1 = 20) # Allowed as we can shuffle between arguments
func(20, var1 = 10) # Runtime Error - You cannot have multiple values
    

#Rule 1 - You cannot have a positional argument or parameter after keyword argument
#Rule 2 - You cannot have a multiple values to a same parameter
    
    


# In[25]:


def func(**kwargs) :
    # **kwargs is just a convention
    # ** accepts n number of keyword parameters from function call
    print(kwargs)

func()
func(a=10)
func(b=[10,20], c=[30,40])
func(a=10,b=20,c=30,d=40,e=50)
    


# In[26]:


# Combination of arguments
def func(a,b,c,*d, **e):
    print(a)
    print(b)
    print(c)
    print(d)
    print(e)
    
func(10,20,30,40,50,60,a=10,b=20,c=30,d=40,e=50)


# In[28]:


help(all)


# In[ ]:


#Lambda function - It is an user defined anonymous function which is used for defining a user defined function which accept multiple values 
# but return only one value


# In[29]:


names = [1,2,3]
all(names)


# In[31]:


names = [0]
all(names)


# In[33]:


matrix = [[1,2],[3,4],[5,6],[7,8]]
transpose = [[row[i] for row in matrix] for i in range(2)]
print(transpose)


# In[39]:


# Lambda Functions
cube = lambda x:x**3
add = lambda a,b:a+b

# 1 
def add(a,b,c) :
    if(a>b) :
        return a+b+c
    else :
        return a*b*c
# 2 - Both 1 and 2 are doing same thing
add = lambda a,b,c:a+b+c if a > b else a*b*c

print(add(10,20,30))
print(cube(20))


# In[40]:


# Lambda Functions - 2
help(filter)


# In[52]:


print(list(filter(lambda x: True if x % 2 == 0 else False, range(1,100))))


# In[63]:


#Prime numbers using lambda
print(list(filter(lambda x: True if all([x%j for j in range(2,x)]) else False, range(2,100))))
help(all)


# In[129]:


name = "Sushant"
#print(name.capitalize()) # Returns string with first character in capital
#print(name.center(len(name))) # Returns center character of string
# help(str.center)
#print(name.count('s')) # Checks the number of specified characters in string
#help(str.endswith)
#print(name.endswith("t")) # checks if string endswith given character
#help(str.find)
#print(name.find('t')) # Returns lowest index where given substring is found
#help(str.format)
# print(name.format('   ')) # Returns formatted version of string
#help(str.join)
#name.join([' ', 'Gorde']) # Appends iterable object to the string
#help(str.index)
#print(name.index('s')) # Returns index of given substring
#help(str.isalnum)
#print(name.isalnum()) # checks if String is alphanumeric or not
#help(str.ljust)
#help(str.lstrip)
#print(name.lstrip()) # Removes leading whitespaces
#help(str.maketrans)
#print(name.maketrans("Shantan","Ratanve"))
#help(str.partition)
#print(name.partition("s")) # Returns a 3-tuple based on separator we are passing
#help(str.replace)
#print(name.replace("Su",'Tu')) # REplace given string with new string
#help(str.split)
#print(name.split("s")) # Splits the string with given separator, Separator is not considered
#help(str.swapcase)
#print(name.swapcase()) # Swaps the cases of haracters in given string
name2 = "trupti"
#help(str.title)
print(name2.title()) # Returns title of string

# Do it for list, dict and str


# In[89]:


dir(str)

