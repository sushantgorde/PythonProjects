__author__ = 'Sushant'

#Functions - Are set of instructions which you are reusable
#Types of functions
#1. Builtin functions
#2. User Defined functions
#3. Class functions / Object functions

#def is used to start defining functions
#In python function has to be defined first before calling
def functionName():
    print('This is statement 1')
    print('This is statement 2')
    print('This is statement 3')
    if True:
        return 10
    else :
        return "Blalalala"
    print("This is dead code") # This is dead code and will not be executed as it is coming after return

functionName() # This is how we call the function
b = functionName() #This is how we call the function and accept return
print(b) #None, because function is not returning any value

####################################################################################################################

var = 20
def functionName(var): #var is local to function
    #Because preference is always given to local variable
    #If local variable is not present then preference is given to global
    print('This is statement 1', var)

functionName([1,2,3]) #Positional parameter
functionName(var = [1,2,3]) # Keyword parameter, This name should match to the name defined in definition
print(var) # This will print global variable

####################################################################################################################

var = 20
def func(var):
    global var # global is a keyword in python to define that you are referring to global object
    #But we cannot have both global and local
    var = 10 # Local variable overriding global variable. This will give error
    print("This is statement",var)

func(var = 10)
print(var) #This will print value 20

######################################################################################################################

#Inner Functions
var = 10
def func():
    var = 20
    print('Inner 1 ', var)
    def func1():
        print('Inner 2',var)
    func1()

func()
print('Outside ', var)

######################################################################################################################

def func(var1, var2 = 10, var3) : #Python will not allow this
    print('This is statement ', var1)
    print('This is statement ', var2)
    print('This is statement ', var3)

func()
func(10,20,[30,40])
func(10,20,30,40,50)

#####################################################################################################################

# Default value to a variable
def func(var1, var2 = 10, var3= None) : #Python will this
    print('This is statement ', var1)
    print('This is statement ', var2)
    print('This is statement ', var3)

func(10,20,30)
func(var1 = 10, var3=20)

#####################################################################################################################